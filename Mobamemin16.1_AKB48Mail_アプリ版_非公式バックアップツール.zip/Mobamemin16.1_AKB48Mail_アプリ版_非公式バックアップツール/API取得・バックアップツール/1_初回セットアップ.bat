@echo off
setlocal
title AKB48 Mail API Capture and Backup - First-time Setup
cd /d "%~dp0"

echo ============================================================
echo  AKB48 Mail API Capture and Backup - First-time Setup
echo ============================================================
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "_runtime_do_not_edit\setup.ps1"
if errorlevel 1 goto :failed

echo.
echo Setup completed successfully.
echo Close this window, then open the launcher file beginning with "2_".
echo.
pause
exit /b 0

:failed
echo.
echo Setup failed. Review the error shown above.
echo This window will remain open until you press a key.
echo.
pause
exit /b 1
