@echo off
setlocal
title AKB48 Mail API Capture and Backup
cd /d "%~dp0"

if not exist "_runtime_do_not_edit\.venv\Scripts\python.exe" (
  echo First-time setup has not completed.
  echo Close this window and open the setup file beginning with "1_" first.
  echo.
  pause
  exit /b 1
)

"_runtime_do_not_edit\.venv\Scripts\python.exe" "app.py"
set "APP_EXIT=%errorlevel%"
if not "%APP_EXIT%"=="0" (
  echo.
  echo The tool stopped with exit code %APP_EXIT%.
  echo Review the error above. This window will remain open until you press a key.
  echo.
  pause
)
exit /b %APP_EXIT%
