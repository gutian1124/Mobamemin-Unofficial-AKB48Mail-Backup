param(
    [switch]$DetectOnly,
    [string[]]$AdditionalPythonPath = @()
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
$venvDir = Join-Path $PSScriptRoot ".venv"
$venvPython = Join-Path $venvDir "Scripts\python.exe"
$requirements = Join-Path $appRoot "requirements.txt"
$probeCode = "import struct,sys; v='%d.%d'%sys.version_info[:2]; ok=sys.version_info[:2] in ((3,12),(3,13),(3,14)) and struct.calcsize('P')==8; print('AKBMAIL_PYTHON_OK|'+v+'|64') if ok else sys.exit(7)"
$candidates = New-Object System.Collections.ArrayList
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$order = 0

# Prevent the new Python Install Manager from installing a runtime merely because
# this detection script probes a missing version. Python installation is a user step.
$env:PYTHON_MANAGER_AUTOMATIC_INSTALL = "false"

function Add-Candidate {
    param(
        [string]$File,
        [string[]]$Prefix,
        [string]$ExpectedVersion,
        [string]$Source
    )
    if ([string]::IsNullOrWhiteSpace($File)) { return }
    $key = $File + "|" + ($Prefix -join " ")
    if (-not $script:seen.Add($key)) { return }
    $script:order += 1
    [void]$script:candidates.Add([PSCustomObject]@{
        File = $File
        Prefix = @($Prefix)
        ExpectedVersion = $ExpectedVersion
        Source = $Source
        Order = $script:order
    })
}

function Add-CommandCandidates {
    param(
        [string]$Name,
        [string[]]$Prefix,
        [string]$ExpectedVersion,
        [string]$Source
    )
    $commands = @(Get-Command $Name -All -ErrorAction SilentlyContinue)
    foreach ($command in $commands) {
        $path = $command.Source
        if ([string]::IsNullOrWhiteSpace($path)) { $path = $command.Definition }
        Add-Candidate -File $path -Prefix $Prefix -ExpectedVersion $ExpectedVersion -Source $Source
    }
}

function Invoke-PythonProbe {
    param($Candidate)
    try {
        $arguments = @($Candidate.Prefix) + @("-c", $script:probeCode)
        $output = @(& $Candidate.File @arguments 2>$null)
        $exitCode = $LASTEXITCODE
        if ($exitCode -ne 0) { return $null }
        $marker = $output | Where-Object { $_ -match '^AKBMAIL_PYTHON_OK\|([0-9]+\.[0-9]+)\|64$' } | Select-Object -First 1
        if (-not $marker) { return $null }
        $version = ([regex]::Match($marker, '^AKBMAIL_PYTHON_OK\|([0-9]+\.[0-9]+)\|64$')).Groups[1].Value
        if ($Candidate.ExpectedVersion -and $version -ne $Candidate.ExpectedVersion) { return $null }
        return [PSCustomObject]@{
            File = $Candidate.File
            Prefix = @($Candidate.Prefix)
            Source = $Candidate.Source
            Version = $version
            Order = $Candidate.Order
        }
    } catch {
        return $null
    }
}

if (Test-Path -LiteralPath $venvPython) {
    Add-Candidate -File $venvPython -Prefix @() -ExpectedVersion "" -Source "existing private environment"
}
foreach ($path in $AdditionalPythonPath) {
    Add-Candidate -File $path -Prefix @() -ExpectedVersion "" -Source "additional test candidate"
}

# Explicit tags work with both the current Python Install Manager and the legacy
# launcher. They avoid an unsupported default runtime masking a supported one.
foreach ($version in @("3.14", "3.13", "3.12")) {
    Add-CommandCandidates -Name "py" -Prefix @("-V:$version") -ExpectedVersion $version -Source "Python launcher / install manager $version"
    Add-CommandCandidates -Name "python$version" -Prefix @() -ExpectedVersion $version -Source "versioned Python alias $version"
}

# PATH defaults are fallbacks only; their actual version and architecture are probed.
Add-CommandCandidates -Name "python" -Prefix @() -ExpectedVersion "" -Source "python command"
Add-CommandCandidates -Name "python3" -Prefix @() -ExpectedVersion "" -Source "python3 command"

# Discover python.org installations even if PATH and the launcher were not enabled.
$knownPatterns = @()
if ($env:LocalAppData) {
    $knownPatterns += (Join-Path $env:LocalAppData "Programs\Python\Python*\python.exe")
}
if ($env:ProgramFiles) {
    $knownPatterns += (Join-Path $env:ProgramFiles "Python*\python.exe")
    $knownPatterns += (Join-Path $env:ProgramFiles "Python\Python*\python.exe")
}
if (${env:ProgramFiles(x86)}) {
    $knownPatterns += (Join-Path ${env:ProgramFiles(x86)} "Python*\python.exe")
}
foreach ($pattern in $knownPatterns) {
    foreach ($file in @(Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue)) {
        Add-Candidate -File $file.FullName -Prefix @() -ExpectedVersion "" -Source "python.org install path"
    }
}

$valid = New-Object System.Collections.ArrayList
foreach ($candidate in $candidates) {
    $result = Invoke-PythonProbe -Candidate $candidate
    if ($result) { [void]$valid.Add($result) }
}
if ($valid.Count -eq 0) {
    Write-Host "No supported 64-bit Python runtime was found." -ForegroundColor Red
    Write-Host "Install Python 3.12, 3.13, or 3.14 x64."
    Write-Host "For Python Install Manager diagnostics, run: py list"
    exit 10
}

$existing = $valid | Where-Object { $_.File -eq $venvPython } | Select-Object -First 1
if ($existing) {
    $selected = $existing
} else {
    $selected = $valid | Sort-Object @{Expression = {[version]$_.Version}; Descending = $true}, Order | Select-Object -First 1
}
$prefixText = $selected.Prefix -join " "
Write-Host ("Selected Python {0} x64: {1} {2}" -f $selected.Version, $selected.File, $prefixText)

if ($DetectOnly) {
    Write-Output ("AKBMAIL_SELECTED|{0}|{1}|{2}" -f $selected.Version, $selected.File, $prefixText)
    exit 0
}

if (-not $existing) {
    if (Test-Path -LiteralPath $venvDir) {
        $runtimeRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') + '\'
        $venvFull = [IO.Path]::GetFullPath($venvDir)
        if (-not $venvFull.StartsWith($runtimeRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe private environment path: $venvFull"
        }
        Remove-Item -LiteralPath $venvFull -Recurse -Force
    }
    Write-Host "[1/3] Creating the private Python environment..."
    $createArgs = @($selected.Prefix) + @("-m", "venv", $venvDir)
    & $selected.File @createArgs
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $venvPython)) {
        throw "Failed to create the private Python environment."
    }
} else {
    Write-Host "[1/3] The private Python environment already exists."
}

Write-Host "[2/3] Installing required libraries. This may take a few minutes..."
& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "Failed to update pip." }
& $venvPython -m pip install -r $requirements
if ($LASTEXITCODE -ne 0) { throw "Failed to install required libraries." }

Write-Host "[3/3] Verifying the installation..."
& $venvPython -c "import requests,bs4,qrcode,mitmproxy; from importlib.metadata import version; print('Verification OK: API/backup tool, mitmproxy '+version('mitmproxy'))"
if ($LASTEXITCODE -ne 0) { throw "Library verification failed." }
& $venvPython -m pip check
if ($LASTEXITCODE -ne 0) { throw "Installed library versions are inconsistent." }

$selectionFile = Join-Path $PSScriptRoot "python-selection.txt"
@(
    "Version=$($selected.Version)",
    "Source=$($selected.Source)",
    "Executable=$($selected.File)",
    "Prefix=$prefixText"
) | Set-Content -LiteralPath $selectionFile -Encoding UTF8
exit 0
