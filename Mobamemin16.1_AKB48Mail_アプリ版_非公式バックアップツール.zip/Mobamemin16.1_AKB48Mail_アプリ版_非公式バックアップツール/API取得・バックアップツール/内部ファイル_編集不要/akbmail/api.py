from __future__ import annotations

import html
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

import requests
from bs4 import BeautifulSoup, NavigableString, Tag


ALLOWED_HOSTS = {
    "list": "api.akb48mail-appli.com",
    "detail": "web.akb48mail-appli.com",
    "image": "img.akb48mail-appli.com",
}
CONDITIONAL_HEADERS = {
    "if-match",
    "if-none-match",
    "if-modified-since",
    "if-unmodified-since",
    "if-range",
}


class BackupError(RuntimeError):
    pass


class AuthenticationError(BackupError):
    pass


class Cancelled(BackupError):
    pass


@dataclass(frozen=True)
class DetailContent:
    text: str
    safe_html: str
    image_urls: list[str]


def validate_capture(capture: dict[str, Any], require: tuple[str, ...] = ("list", "detail")) -> None:
    for kind in require:
        item = capture.get(kind)
        if not isinstance(item, dict):
            raise BackupError(f"{kind}用の通信情報がありません。iPhone通信を再取得してください。")
        url = str(item.get("url") or "")
        parsed = urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname != ALLOWED_HOSTS[kind]:
            raise BackupError(f"{kind}用URLがAKB48 Mailの想定ホストではありません。")
        headers = item.get("headers")
        if not isinstance(headers, list) or not headers:
            raise BackupError(f"{kind}用Request Headersがありません。")


def captured_headers(item: dict[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for pair in item.get("headers") or []:
        if not isinstance(pair, list) or len(pair) != 2:
            continue
        name, value = str(pair[0]), str(pair[1])
        if name.lower() in CONDITIONAL_HEADERS:
            continue
        result[name] = value
    return result


def url_with_page(url: str, page: int) -> str:
    parsed = urlsplit(url)
    query = parse_qsl(parsed.query, keep_blank_values=True)
    replaced = False
    result: list[tuple[str, str]] = []
    for key, value in query:
        if key == "page":
            if not replaced:
                result.append((key, str(page)))
                replaced = True
        else:
            result.append((key, value))
    if not replaced:
        result.append(("page", str(page)))
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(result), parsed.fragment))


class AkbMailClient:
    def __init__(
        self,
        capture: dict[str, Any],
        stop_event: threading.Event | None = None,
        log: Callable[[str], None] | None = None,
    ):
        validate_capture(capture)
        self.capture = capture
        self.stop_event = stop_event or threading.Event()
        self.log = log or (lambda message: None)
        self.session = requests.Session()

    def close(self) -> None:
        self.session.close()

    def __enter__(self) -> "AkbMailClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def get_list(self, page: int) -> dict[str, Any]:
        item = self.capture["list"]
        url = url_with_page(str(item["url"]), page)
        response = self._get("list", url)
        try:
            payload = response.json()
        except ValueError as exc:
            raise BackupError(f"一覧APIの応答がJSONではありません（page={page}）。") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("mails"), list):
            raise BackupError(f"一覧APIの形式が想定と異なります（page={page}）。")
        response_page = payload.get("page")
        if response_page is not None and int(response_page) != page:
            raise BackupError(f"一覧APIから異なるページが返りました（要求={page}, 応答={response_page}）。")
        return payload

    def get_detail(self, url: str) -> str:
        self._validate_url("detail", url)
        response = self._get("detail", url)
        encoding = response.encoding or "utf-8"
        return response.content.decode(encoding, errors="replace")

    def get_image(self, url: str) -> tuple[bytes, str | None]:
        if "image" not in self.capture:
            raise BackupError(
                "画像用Request Headersが未取得です。画像付きメールをiPhoneで開き、通信取得をやり直してください。"
            )
        validate_capture(self.capture, require=("image",))
        self._validate_url("image", url)
        response = self._get("image", url)
        content_type = response.headers.get("Content-Type")
        media_type = (content_type or "").split(";", 1)[0].strip().lower()
        if media_type and not media_type.startswith("image/"):
            raise BackupError(f"画像URLから画像以外が返りました（Content-Type: {media_type}）。")
        if len(response.content) > 100 * 1024 * 1024:
            raise BackupError("画像が100MBの安全上限を超えたため保存しませんでした。")
        return response.content, content_type

    def _validate_url(self, kind: str, url: str) -> None:
        parsed = urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname != ALLOWED_HOSTS[kind]:
            raise BackupError(f"安全のため想定外の{kind} URLへの通信を拒否しました: {url}")

    def _get(self, kind: str, url: str) -> requests.Response:
        self._validate_url(kind, url)
        headers = captured_headers(self.capture[kind])
        last_error: Exception | None = None
        for attempt in range(1, 4):
            if self.stop_event.is_set():
                raise Cancelled("ユーザーがバックアップを中止しました。")
            try:
                response = self.session.get(
                    url,
                    headers=headers,
                    timeout=(15, 90),
                    allow_redirects=False,
                )
                if response.status_code in (401, 403):
                    raise AuthenticationError(
                        f"認証が拒否されました（HTTP {response.status_code}）。iPhone通信を再取得してください。"
                    )
                if 300 <= response.status_code < 400:
                    raise BackupError(
                        f"予期しないリダイレクトを拒否しました（HTTP {response.status_code}）。"
                    )
                if response.status_code == 429 or 500 <= response.status_code < 600:
                    if attempt == 3:
                        response.raise_for_status()
                    wait = _retry_delay(response.headers.get("Retry-After"), attempt)
                    self.log(f"HTTP {response.status_code}。{wait}秒後に再試行します ({attempt}/3)")
                    self._wait(wait)
                    continue
                response.raise_for_status()
                return response
            except (requests.Timeout, requests.ConnectionError) as exc:
                last_error = exc
                if attempt == 3:
                    break
                wait = 2**attempt
                self.log(f"通信エラー。{wait}秒後に再試行します ({attempt}/3): {exc}")
                self._wait(wait)
            except requests.HTTPError as exc:
                last_error = exc
                break
        raise BackupError(f"通信に失敗しました: {last_error}") from last_error

    def _wait(self, seconds: int) -> None:
        if self.stop_event.wait(seconds):
            raise Cancelled("ユーザーがバックアップを中止しました。")


def _retry_delay(value: str | None, attempt: int) -> int:
    try:
        return min(60, max(1, int(value or "")))
    except ValueError:
        return min(30, 2**attempt)


def extract_detail(document: str, base_url: str) -> DetailContent:
    soup = BeautifulSoup(document, "html.parser")
    container = soup.select_one("#mail-detail")
    if container is None:
        raise BackupError("詳細HTMLに #mail-detail が見つかりません。仕様が変わった可能性があります。")

    image_urls: list[str] = []
    for image in list(container.find_all("img")):
        source = str(image.get("src") or "").strip()
        if source:
            absolute = urljoin(base_url, source)
            parsed_image = urlsplit(absolute)
            if (
                parsed_image.scheme == "https"
                and parsed_image.hostname == ALLOWED_HOSTS["image"]
            ):
                image_urls.append(absolute)
                replacement = soup.new_tag("span")
                replacement["class"] = "image-marker"
                replacement.string = f"［画像 {len(image_urls)}］"
            else:
                replacement = soup.new_tag("span")
                replacement.string = "［保存対象外の画像］"
            image.replace_with(replacement)
        else:
            image.decompose()

    for tag in list(container.find_all(["script", "style", "iframe", "object", "embed", "form", "link", "meta", "svg", "math"])):
        tag.decompose()

    allowed = {"br", "p", "div", "span", "b", "strong", "i", "em", "u", "blockquote", "ul", "ol", "li"}
    for tag in list(container.find_all(True)):
        if tag.name not in allowed:
            tag.unwrap()
            continue
        classes = tag.get("class", []) if tag.name == "span" else []
        if isinstance(classes, str):
            classes = classes.split()
        tag.attrs = {}
        if "image-marker" in classes:
            tag["class"] = "image-marker"

    text = _normalized_text(container)
    return DetailContent(text=text, safe_html=str(container.decode_contents()), image_urls=image_urls)


def _normalized_text(container: Tag) -> str:
    lines = [line.rstrip() for line in container.get_text("\n").splitlines()]
    result: list[str] = []
    previous_blank = True
    for line in lines:
        blank = not line.strip()
        if blank and previous_blank:
            continue
        result.append("" if blank else html.unescape(line.strip()))
        previous_blank = blank
    return "\n".join(result).strip()
