from __future__ import annotations

import hashlib
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urlsplit

from .api import AkbMailClient, AuthenticationError, BackupError, Cancelled, extract_detail
from .sleep import PreventSleep
from .storage import Storage, safe_component


@dataclass(frozen=True)
class BackupOptions:
    limit: int | None
    request_interval: float = 0.35


@dataclass
class BackupSummary:
    listed: int = 0
    details_completed: int = 0
    details_skipped: int = 0
    images_completed: int = 0
    images_skipped: int = 0
    errors: int = 0
    cancelled: bool = False


class BackupRunner:
    def __init__(
        self,
        storage: Storage,
        capture: dict[str, object],
        options: BackupOptions,
        stop_event: threading.Event,
        log: Callable[[str], None],
        progress: Callable[[int, int, str], None] | None = None,
    ):
        self.storage = storage
        self.capture = capture
        self.options = options
        self.stop_event = stop_event
        self.log = log
        self.progress = progress or (lambda current, total, message: None)

    def run(self) -> BackupSummary:
        summary = BackupSummary()
        with PreventSleep(), AkbMailClient(
            self.capture, stop_event=self.stop_event, log=self.log
        ) as client:
            try:
                self._fetch_lists(client, summary)
                self._fetch_details(client, summary)
            except Cancelled:
                summary.cancelled = True
                self.log("バックアップを中止しました。保存済みの位置から再開できます。")
        return summary

    def _fetch_lists(self, client: AkbMailClient, summary: BackupSummary) -> None:
        page = 1
        checkpoint = self.storage.get_metadata("list_checkpoint", {})
        if (
            self.options.limit is None
            and isinstance(checkpoint, dict)
            and checkpoint.get("in_progress")
        ):
            page = max(1, int(checkpoint.get("next_page") or 1))
            if page > 1:
                self.log(f"中断した一覧取得を page={page} から再開します。")
        self.storage.set_metadata(
            "list_checkpoint",
            {"in_progress": True, "next_page": page, "mode": "all" if self.options.limit is None else "limited"},
        )
        remaining = self.options.limit
        while True:
            self._check_cancelled()
            self.progress(summary.listed, self.options.limit or 0, f"一覧 {page}ページ目を取得中")
            payload = client.get_list(page)
            self.storage.save_raw_list(page, payload)
            mails = list(payload.get("mails") or [])
            selected = mails if remaining is None else mails[: max(0, remaining)]
            summary.listed += self.storage.upsert_mails(selected)
            self.log(
                f"一覧 page={page}: 応答{len(mails)}件、対象{len(selected)}件 "
                f"(has_next_page={bool(payload.get('has_next_page'))})"
            )
            if remaining is not None:
                remaining -= len(selected)
                if remaining <= 0:
                    break
            if not payload.get("has_next_page") or not mails:
                break
            page += 1
            self.storage.set_metadata(
                "list_checkpoint",
                {"in_progress": True, "next_page": page, "mode": "all" if self.options.limit is None else "limited"},
            )
            if page > 100000:
                raise BackupError("ページ数が上限を超えました。APIのページ情報を確認してください。")
            self._interval()
        self.storage.set_metadata("last_list_page", page)
        self.storage.set_metadata(
            "list_checkpoint",
            {"in_progress": False, "next_page": 1, "mode": "all" if self.options.limit is None else "limited"},
        )

    def _fetch_details(self, client: AkbMailClient, summary: BackupSummary) -> None:
        mails = self.storage.selected_mails(self.options.limit)
        total = len(mails)
        for index, mail in enumerate(mails, start=1):
            self._check_cancelled()
            mail_id = str(mail["id"])
            self.progress(index - 1, total, f"{index}/{total} {mail['member_name']} - {mail['subject']}")
            try:
                if mail["detail_status"] == "complete" and mail["body_text"] is not None:
                    summary.details_skipped += 1
                else:
                    document = client.get_detail(str(mail["detail_url"]))
                    raw_path = self.storage.save_raw_detail(mail_id, document)
                    detail = extract_detail(document, str(mail["detail_url"]))
                    self.storage.upsert_images(mail_id, detail.image_urls)
                    self.storage.mark_detail_complete(
                        mail_id, raw_path, detail.text, detail.safe_html
                    )
                    summary.details_completed += 1
                    self.log(f"本文保存: {mail_id} / {mail['member_name']} / {mail['subject']}")
                    self._interval()
                self._fetch_images(client, mail_id, summary)
            except AuthenticationError:
                raise
            except Cancelled:
                raise
            except Exception as exc:
                summary.errors += 1
                self.storage.mark_detail_error(mail_id, str(exc))
                self.log(f"エラー {mail_id}: {exc}")
            self.progress(index, total, f"{index}/{total} 完了")

    def _fetch_images(
        self, client: AkbMailClient, mail_id: str, summary: BackupSummary
    ) -> None:
        for image in self.storage.images_for_mail(mail_id):
            self._check_cancelled()
            if image["status"] == "complete" and image["local_path"]:
                path = self.storage.data_dir / str(image["local_path"])
                if path.is_file() and path.stat().st_size > 0:
                    summary.images_skipped += 1
                    continue
            try:
                content, content_type = client.get_image(str(image["url"]))
                if not content:
                    raise BackupError("画像の応答が空です。")
                path = self._image_path(
                    mail_id,
                    int(image["position"]),
                    str(image["url"]),
                    content_type,
                )
                path.parent.mkdir(parents=True, exist_ok=True)
                temporary = path.with_suffix(path.suffix + ".part")
                temporary.write_bytes(content)
                os.replace(temporary, path)
                self.storage.mark_image_complete(int(image["id"]), path, content_type)
                summary.images_completed += 1
                self.log(f"画像保存: {mail_id} / {path.name}")
                self._interval()
            except Cancelled:
                raise
            except Exception as exc:
                summary.errors += 1
                self.storage.mark_image_error(int(image["id"]), str(exc))
                self.log(f"画像エラー {mail_id}: {exc}")

    def _image_path(
        self,
        mail_id: str,
        position: int,
        url: str,
        content_type: str | None,
    ) -> Path:
        extension = _image_extension(url, content_type)
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:10]
        return (
            self.storage.image_dir
            / safe_component(mail_id)
            / f"{position + 1:02d}_{digest}{extension}"
        )

    def _interval(self) -> None:
        if self.stop_event.wait(self.options.request_interval):
            raise Cancelled("ユーザーがバックアップを中止しました。")

    def _check_cancelled(self) -> None:
        if self.stop_event.is_set():
            raise Cancelled("ユーザーがバックアップを中止しました。")


def _image_extension(url: str, content_type: str | None) -> str:
    media = (content_type or "").split(";", 1)[0].strip().lower()
    by_type = {
        "image/jpeg": ".jpg",
        "image/png": ".png",
        "image/gif": ".gif",
        "image/webp": ".webp",
        "image/heic": ".heic",
        "image/heif": ".heif",
    }
    if media in by_type:
        return by_type[media]
    suffix = Path(urlsplit(url).path).suffix.lower()
    return suffix if suffix in set(by_type.values()) | {".jpeg"} else ".img"
