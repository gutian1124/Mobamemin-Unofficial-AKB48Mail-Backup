from __future__ import annotations

import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from .security import load_secret_json, save_secret_json


ANSI_ESCAPE = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")
IMPORTANT_PROXY_MESSAGES = (
    "akb48 mail",
    "address already",
    "winerror 10013",
    "winerror 10048",
    "error loading script",
    "error in addon",
    "failed to start",
    "proxy server failed",
    "cannot listen",
    "tls handshake failed",
    "certificate verify failed",
    "invalid certificate",
    "modulenotfounderror",
    "permissionerror",
    "no such file",
)


def proxy_environment(base: dict[str, str] | None = None) -> dict[str, str]:
    """Force deterministic UTF-8 output from the Python-based mitmdump child."""
    environment = dict(os.environ if base is None else base)
    environment["PYTHONUTF8"] = "1"
    environment["PYTHONIOENCODING"] = "utf-8:replace"
    environment["NO_COLOR"] = "1"
    return environment


def clean_proxy_line(value: str) -> str:
    return ANSI_ESCAPE.sub("", value).strip()


def is_benign_connection_reset(value: str) -> bool:
    lowered = value.lower()
    return "winerror 10054" in lowered or (
        "connectionreseterror" in lowered and "forcibly closed" in lowered
    )


def should_display_proxy_line(value: str) -> bool:
    if is_benign_connection_reset(value):
        return False
    lowered = value.lower()
    return any(token in lowered for token in IMPORTANT_PROXY_MESSAGES)


class CaptureManager:
    def __init__(
        self,
        internal_dir: Path,
        log: Callable[[str], None] | None = None,
        port: int = 8080,
    ):
        self.internal_dir = internal_dir
        self.state_dir = internal_dir / "状態"
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.port = port
        self.log = log or (lambda message: None)
        self.pending_path = self.state_dir / "capture_pending.json"
        self.secret_path = self.state_dir / "認証情報.dat"
        self.conf_dir = self.state_dir / "mitmproxy"
        self.process: subprocess.Popen[str] | None = None
        self._reader: threading.Thread | None = None
        self._recent_relevant: deque[str] = deque(maxlen=8)
        self._suppressed_resets = 0
        self.session_started_at: datetime | None = None

    def start(self) -> None:
        if self.is_running:
            return
        self._recent_relevant.clear()
        self._suppressed_resets = 0
        self.session_started_at = datetime.now(timezone.utc)
        try:
            self.pending_path.unlink(missing_ok=True)
        except OSError as exc:
            raise RuntimeError(f"一時認証ファイルを初期化できません: {exc}") from exc
        executable = Path(sys.executable).with_name("mitmdump.exe")
        if not executable.exists():
            raise RuntimeError("mitmdumpが見つかりません。初回セットアップをやり直してください。")
        addon = self.internal_dir / "capture_addon.py"
        environment = proxy_environment()
        # The addon writes DPAPI-protected data directly. pending_path is retained
        # only to recover plaintext hand-offs created by versions before 1.1.
        environment["AKBMAIL_CAPTURE_PATH"] = str(self.secret_path)
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        command = [
            str(executable),
            "--listen-host",
            "0.0.0.0",
            "--listen-port",
            str(self.port),
            "--set",
            f"confdir={self.conf_dir}",
            "--set",
            "block_global=false",
            "--allow-hosts",
            r"^(api|web|img)\.akb48mail-appli\.com(?::\d+)?$",
            "--allow-hosts",
            r"^mitm\.it(?::\d+)?$",
            "-s",
            str(addon),
        ]
        self.process = subprocess.Popen(
            command,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=flags,
        )
        self._reader = threading.Thread(target=self._read_output, daemon=True)
        self._reader.start()
        # A cold first launch can take several seconds while Python imports
        # mitmproxy.  Do not report success until the listener is actually ready.
        ready = False
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                break
            try:
                with socket.create_connection(("127.0.0.1", self.port), timeout=0.25):
                    ready = True
                    break
            except OSError:
                time.sleep(0.1)
        if not ready:
            details = "\n".join(self._recent_relevant)
            suffix = f"\n{details}" if details else ""
            if self.process.poll() is None:
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=2)
            self.process = None
            raise RuntimeError(
                f"通信取得プロキシを開始できませんでした（10秒以内に待受を確認できません）。{suffix}"
            )
        self.log(f"通信取得を開始しました（ポート {self.port}）。停止するまで待機します。")

    @property
    def is_running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def import_pending(self) -> dict[str, object]:
        if not self.pending_path.exists():
            return self.load_capture()
        try:
            data = json.loads(self.pending_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("capture root is not an object")
            save_secret_json(self.secret_path, data)
            self.pending_path.unlink(missing_ok=True)
            return data
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            self.log(f"取得情報の読み込みを再試行します: {exc}")
            return self.load_capture()

    def load_capture(self) -> dict[str, object]:
        return load_secret_json(self.secret_path)

    def is_current_session_item(self, item: object) -> bool:
        if self.session_started_at is None or not isinstance(item, dict):
            return False
        captured_at = str(item.get("captured_at") or "")
        if not captured_at:
            return False
        try:
            timestamp = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=timezone.utc)
        except ValueError:
            return False
        return timestamp >= self.session_started_at

    def stop(self) -> dict[str, object]:
        process = self.process
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)
        self.process = None
        data = self.import_pending()
        self.log("通信取得を停止しました。iPhoneのWi-Fiプロキシを「オフ」に戻してください。")
        return data

    def _read_output(self) -> None:
        process = self.process
        if process is None or process.stdout is None:
            return
        for raw_line in process.stdout:
            line = clean_proxy_line(raw_line)
            if not line:
                continue
            if is_benign_connection_reset(line):
                self._suppressed_resets += 1
                continue
            # Normal proxy traffic is intentionally hidden. Only capture confirmations
            # and errors that require user action are copied to the GUI log.
            if should_display_proxy_line(line):
                compact = line[-500:]
                self._recent_relevant.append(compact)
                self.log(compact)
