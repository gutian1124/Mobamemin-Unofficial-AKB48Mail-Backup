from __future__ import annotations

import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any

import qrcode
from PIL import Image, ImageTk

from .api import validate_capture
from .backup import BackupOptions, BackupRunner, BackupSummary
from .capture import CaptureManager
from .network import local_ipv4_addresses
from .storage import Storage


class AkbMailApp:
    def __init__(self, root: tk.Tk, app_root: Path, data_dir: Path):
        self.root = root
        self.app_root = app_root
        self.internal_dir = app_root / "内部ファイル_編集不要"
        self.data_dir = data_dir
        self.storage = Storage(self.data_dir)
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.capture_manager = CaptureManager(self.internal_dir, log=self._thread_log)
        try:
            # Recover and encrypt a plaintext hand-off left by an unexpected prior exit.
            self.capture_manager.import_pending()
        except Exception as exc:
            self._thread_log(f"前回の一時認証情報を回収できません: {exc}")
        self.backup_thread: threading.Thread | None = None
        self.backup_stop = threading.Event()
        self.closing = False
        self.qr_images: list[ImageTk.PhotoImage] = []

        self.root.title("AKB48 Mail API取得・バックアップ")
        self.root.geometry("980x720")
        self.root.minsize(840, 620)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._configure_style()
        self._build_ui()
        self._refresh_capture_status()
        self._refresh_counts()
        self.root.after(150, self._process_events)
        self.root.after(1000, self._poll_capture)

    def _configure_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Yu Gothic UI", 18, "bold"))
        style.configure("Heading.TLabel", font=("Yu Gothic UI", 12, "bold"))
        style.configure("Good.TLabel", foreground="#188038", font=("Yu Gothic UI", 10, "bold"))
        style.configure("Wait.TLabel", foreground="#9c4f00")
        style.configure("Accent.TButton", font=("Yu Gothic UI", 10, "bold"))

    def _build_ui(self) -> None:
        header = ttk.Frame(self.root, padding=(18, 14))
        header.pack(fill="x")
        ttk.Label(header, text="AKB48 Mail API取得・バックアップ", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="iPhoneの実測通信を取得し、メール本文と画像をPCへ保存します。",
        ).pack(anchor="w", pady=(3, 0))
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.capture_tab = ttk.Frame(self.notebook, padding=16)
        self.backup_tab = ttk.Frame(self.notebook, padding=16)
        self.notebook.add(self.capture_tab, text="1. iPhone通信を取得")
        self.notebook.add(self.backup_tab, text="2. バックアップ")
        self._build_capture_tab()
        self._build_backup_tab()

    def _build_capture_tab(self) -> None:
        # Keep the primary controls at the top. On some Windows display-scaling
        # configurations a maximized Tk window extends behind the taskbar, so
        # controls placed after the long setup guide can otherwise be obscured.
        controls = ttk.Frame(self.capture_tab)
        controls.pack(fill="x", pady=(0, 14))
        self.capture_start_button = ttk.Button(
            controls, text="通信取得を開始", style="Accent.TButton", command=self._start_capture
        )
        self.capture_start_button.pack(side="left")
        self.capture_stop_button = ttk.Button(
            controls, text="通信取得を停止", command=self._stop_capture, state="disabled"
        )
        self.capture_stop_button.pack(side="left", padx=8)
        self.capture_running_var = tk.StringVar(value="停止中")
        ttk.Label(controls, textvariable=self.capture_running_var).pack(side="left", padx=10)

        top = ttk.Frame(self.capture_tab)
        top.pack(fill="x")
        instructions = (
            "① PCとiPhoneを同じ信頼できるWi-Fiへ接続\n"
            "② 下の「通信取得を開始」→ iPhoneのWi-Fi設定でHTTPプロキシを「手動」\n"
            "③ サーバにPCのIP、ポートに8080を入力\n"
            "④ Safariで http://mitm.it を開き、iOS証明書をダウンロード\n"
            "⑤ 設定 ＞ 一般 ＞ VPNとデバイス管理 でプロファイルをインストール\n"
            "⑥ 設定 ＞ 一般 ＞ 情報 ＞ 証明書信頼設定で mitmproxy を全面的に信頼\n"
            "⑦ AKB48 Mailで受信箱を開き、画像付きメールを1通開く\n"
            "⑧ 3項目が「今回取得済み」になったら停止し、iPhoneのプロキシをオフ"
        )
        ttk.Label(top, text="iPhone側の手順", style="Heading.TLabel").pack(anchor="w")
        ttk.Label(top, text=instructions, justify="left", wraplength=650).pack(
            side="left", anchor="nw", pady=(8, 12)
        )
        qr_frame = ttk.Frame(top)
        qr_frame.pack(side="right", padx=(15, 0), anchor="n")
        self._add_qr(qr_frame, "http://mitm.it", "証明書URL")

        connection = ttk.LabelFrame(self.capture_tab, text="PC側の接続情報", padding=12)
        connection.pack(fill="x", pady=(0, 12))
        addresses = ", ".join(local_ipv4_addresses()) or "取得できませんでした"
        ttk.Label(connection, text=f"サーバ（IP）: {addresses}", font=("Consolas", 11, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Label(connection, text="ポート: 8080", font=("Consolas", 11, "bold")).grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Label(connection, text="証明書URL: http://mitm.it", font=("Consolas", 11, "bold")).grid(row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Label(
            connection,
            text="※ 複数のIPがある場合は、iPhoneと同じWi-Fi側の 192.168.x.x / 10.x.x.x を選びます。",
        ).grid(row=3, column=0, sticky="w", pady=(7, 0))

        status = ttk.LabelFrame(self.capture_tab, text="取得状況（ヘッダー値自体は画面に表示しません）", padding=12)
        status.pack(fill="x")
        self.capture_status_vars: dict[str, tk.StringVar] = {}
        labels = {"list": "メール一覧", "detail": "メール詳細", "image": "メール画像"}
        for row, (kind, label) in enumerate(labels.items()):
            ttk.Label(status, text=label, width=16).grid(row=row, column=0, sticky="w", pady=3)
            variable = tk.StringVar(value="未取得")
            self.capture_status_vars[kind] = variable
            ttk.Label(status, textvariable=variable).grid(row=row, column=1, sticky="w", pady=3)
    def _add_qr(self, parent: ttk.Frame, value: str, caption: str) -> None:
        image = qrcode.make(value).convert("RGB").resize((142, 142), Image.Resampling.NEAREST)
        photo = ImageTk.PhotoImage(image)
        self.qr_images.append(photo)
        ttk.Label(parent, image=photo).pack()
        ttk.Label(parent, text=caption).pack()

    def _build_backup_tab(self) -> None:
        ttk.Label(self.backup_tab, text="取得件数", style="Heading.TLabel").pack(anchor="w")
        options = ttk.Frame(self.backup_tab)
        options.pack(fill="x", pady=(8, 12))
        self.limit_mode = tk.StringVar(value="test")
        ttk.Radiobutton(options, text="テスト（最新1件）", variable=self.limit_mode, value="test").pack(side="left")
        ttk.Radiobutton(options, text="件数を指定", variable=self.limit_mode, value="custom").pack(side="left", padx=(16, 4))
        self.limit_value = tk.StringVar(value="100")
        ttk.Spinbox(options, from_=1, to=1000000, width=10, textvariable=self.limit_value).pack(side="left")
        ttk.Radiobutton(options, text="全件", variable=self.limit_mode, value="all").pack(side="left", padx=16)

        controls = ttk.Frame(self.backup_tab)
        controls.pack(fill="x")
        self.backup_start_button = ttk.Button(
            controls, text="バックアップを開始", style="Accent.TButton", command=self._start_backup
        )
        self.backup_start_button.pack(side="left")
        self.backup_stop_button = ttk.Button(
            controls, text="安全に中止", command=self._stop_backup, state="disabled"
        )
        self.backup_stop_button.pack(side="left", padx=8)
        self.backup_status_var = tk.StringVar(value="待機中")
        ttk.Label(controls, textvariable=self.backup_status_var).pack(side="left", padx=10)
        self.progress = ttk.Progressbar(self.backup_tab, mode="determinate")
        self.progress.pack(fill="x", pady=(12, 8))

        ttk.Label(
            self.backup_tab,
            text="処理中はWindowsのスリープを抑止します。完了済みの本文・画像は再実行時に飛ばします。",
        ).pack(anchor="w", pady=(0, 8))
        status_frame = ttk.LabelFrame(
            self.backup_tab, text="共有バックアップデータの保存状況", padding=10
        )
        status_frame.pack(fill="x", pady=(0, 10))
        self.counts_var = tk.StringVar(value="保存状況を確認中...")
        ttk.Label(
            status_frame,
            textvariable=self.counts_var,
            font=("Yu Gothic UI", 11, "bold"),
            justify="left",
        ).pack(side="left", anchor="w")
        ttk.Button(
            status_frame, text="保存状況を更新", command=self._refresh_counts
        ).pack(side="right", padx=(12, 0))
        ttk.Label(
            self.backup_tab,
            text=f"保存先: {self.data_dir}",
            wraplength=900,
        ).pack(anchor="w", pady=(0, 8))
        log_frame = ttk.LabelFrame(self.backup_tab, text="処理ログ（認証情報は表示しません）", padding=6)
        log_frame.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_frame, height=18, wrap="word", state="disabled", font=("Consolas", 9))
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def _start_capture(self) -> None:
        try:
            self.capture_manager.start()
        except Exception as exc:
            messagebox.showerror("通信取得を開始できません", str(exc), parent=self.root)
            self._append_log(f"通信取得エラー: {exc}")
            return
        self.capture_start_button.configure(state="disabled")
        self.capture_stop_button.configure(state="normal")
        self.capture_running_var.set("取得中（ユーザーが停止するまで待機）")
        self._refresh_capture_status()

    def _stop_capture(self) -> None:
        try:
            self.capture_manager.stop()
        except Exception as exc:
            messagebox.showerror("通信取得の停止エラー", str(exc), parent=self.root)
        self.capture_start_button.configure(state="normal")
        self.capture_stop_button.configure(state="disabled")
        self.capture_running_var.set("停止中 — iPhoneのプロキシをオフにしてください")
        self._refresh_capture_status()

    def _poll_capture(self) -> None:
        if self.capture_manager.is_running:
            self.capture_manager.import_pending()
            self._refresh_capture_status()
        elif str(self.capture_stop_button["state"]) == "normal":
            self.capture_start_button.configure(state="normal")
            self.capture_stop_button.configure(state="disabled")
            self.capture_running_var.set("予期せず停止しました。ログを確認してください。")
        self.root.after(1000, self._poll_capture)

    def _refresh_capture_status(self) -> None:
        try:
            capture = self.capture_manager.load_capture()
        except Exception as exc:
            capture = {}
            self._append_log(f"保存済み認証情報を読めません: {exc}")
        for kind, variable in self.capture_status_vars.items():
            item = capture.get(kind)
            if isinstance(item, dict):
                count = len(item.get("headers") or [])
                if self.capture_manager.is_current_session_item(item):
                    variable.set(f"今回取得済み（Request Headers {count}項目）")
                elif self.capture_manager.session_started_at is not None:
                    variable.set(
                        f"前回分あり・今回未取得（Request Headers {count}項目）"
                    )
                else:
                    variable.set(f"保存済み・前回分（Request Headers {count}項目）")
            else:
                variable.set("未取得")

    def _selected_limit(self) -> int | None:
        mode = self.limit_mode.get()
        if mode == "test":
            return 1
        if mode == "all":
            return None
        try:
            value = int(self.limit_value.get())
        except ValueError as exc:
            raise ValueError("取得件数は1以上の整数で入力してください。") from exc
        if value < 1:
            raise ValueError("取得件数は1以上にしてください。")
        return value

    def _start_backup(self) -> None:
        if self.backup_thread is not None and self.backup_thread.is_alive():
            return
        try:
            limit = self._selected_limit()
            capture = self.capture_manager.load_capture()
            validate_capture(capture)
        except Exception as exc:
            messagebox.showerror("バックアップを開始できません", str(exc), parent=self.root)
            return
        self.backup_stop.clear()
        self.backup_start_button.configure(state="disabled")
        self.backup_stop_button.configure(state="normal")
        self.backup_status_var.set("開始しています...")
        self.progress.configure(value=0, maximum=max(1, limit or 1))
        self.backup_thread = threading.Thread(
            target=self._backup_worker, args=(capture, limit), daemon=True
        )
        self.backup_thread.start()

    def _backup_worker(self, capture: dict[str, object], limit: int | None) -> None:
        try:
            runner = BackupRunner(
                self.storage,
                capture,
                BackupOptions(limit=limit),
                self.backup_stop,
                self._thread_log,
                progress=lambda current, total, message: self.events.put(
                    ("progress", (current, total, message))
                ),
            )
            summary = runner.run()
            self.events.put(("backup_done", summary))
        except Exception as exc:
            self.events.put(("backup_error", exc))

    def _stop_backup(self) -> None:
        self.backup_stop.set()
        self.backup_status_var.set("安全に中止しています...")
        self.backup_stop_button.configure(state="disabled")

    def _refresh_counts(self) -> None:
        counts = self.storage.counts()
        self.counts_var.set(
            f"一覧 {counts['total']}件　本文 完了{counts['complete']} / "
            f"未処理{counts['detail_pending']} / エラー{counts['detail_errors']}\n"
            f"画像 対象{counts['image_total']}　完了{counts['image_complete']} / "
            f"未処理{counts['image_pending']} / エラー{counts['image_errors']} / "
            f"ファイル欠損{counts['image_missing']}"
        )

    def _thread_log(self, message: str) -> None:
        self.events.put(("log", message))

    def _process_events(self) -> None:
        while True:
            try:
                kind, payload = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == "log":
                self._append_log(str(payload))
            elif kind == "progress":
                current, total, message = payload
                if total:
                    self.progress.configure(maximum=total, value=current)
                self.backup_status_var.set(message)
            elif kind == "backup_done":
                self._backup_finished(payload)
            elif kind == "backup_error":
                self._backup_failed(payload)
        self.root.after(150, self._process_events)

    def _append_log(self, message: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message.rstrip() + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _backup_finished(self, summary: BackupSummary) -> None:
        self.backup_start_button.configure(state="normal")
        self.backup_stop_button.configure(state="disabled")
        counts = self.storage.counts()
        outstanding = (
            counts["detail_pending"]
            + counts["detail_errors"]
            + counts["image_pending"]
            + counts["image_errors"]
            + counts["image_missing"]
        )
        if summary.cancelled:
            state = "中止"
        elif summary.errors or outstanding:
            state = "未完了（要再実行）"
        else:
            state = "完了"
        message = (
            f"{state}: 本文 新規{summary.details_completed} / 省略{summary.details_skipped}、"
            f"画像 新規{summary.images_completed} / 省略{summary.images_skipped}、"
            f"今回のエラー{summary.errors}、保存全体の未完了{outstanding}"
        )
        self.backup_status_var.set(message)
        self._append_log(message)
        self._refresh_counts()
        if not summary.cancelled and not self.closing:
            if summary.errors or outstanding:
                messagebox.showwarning(
                    "バックアップは未完了です",
                    message + "\nエラーまたは未処理が0件になるまで再実行してください。",
                    parent=self.root,
                )
            else:
                messagebox.showinfo("バックアップ完了", message, parent=self.root)

    def _backup_failed(self, exc: Exception) -> None:
        self.backup_start_button.configure(state="normal")
        self.backup_stop_button.configure(state="disabled")
        self.backup_status_var.set("エラーで停止")
        self._append_log(f"バックアップ停止: {exc}")
        self._refresh_counts()
        if not self.closing:
            messagebox.showerror("バックアップエラー", str(exc), parent=self.root)

    def _on_close(self) -> None:
        if self.closing:
            return
        if self.backup_thread is not None and self.backup_thread.is_alive():
            if not messagebox.askyesno(
                "処理中です",
                "バックアップを安全に中止して終了しますか？\n保存済みの位置から再開できます。",
                parent=self.root,
            ):
                return
            self.closing = True
            self.backup_stop.set()
            self.backup_status_var.set("安全に中止して終了するまで待っています...")
            self.backup_start_button.configure(state="disabled")
            self.backup_stop_button.configure(state="disabled")
            self.root.after(200, self._finish_close_when_idle)
            return
        self._final_close()

    def _finish_close_when_idle(self) -> None:
        if self.backup_thread is not None and self.backup_thread.is_alive():
            self.root.after(200, self._finish_close_when_idle)
            return
        self._final_close()

    def _final_close(self) -> None:
        if self.capture_manager.is_running:
            try:
                self.capture_manager.stop()
            except Exception:
                pass
        self.root.destroy()


def run_app(app_root: Path, data_dir: Path) -> None:
    root = tk.Tk()
    AkbMailApp(root, app_root, data_dir)
    root.mainloop()
