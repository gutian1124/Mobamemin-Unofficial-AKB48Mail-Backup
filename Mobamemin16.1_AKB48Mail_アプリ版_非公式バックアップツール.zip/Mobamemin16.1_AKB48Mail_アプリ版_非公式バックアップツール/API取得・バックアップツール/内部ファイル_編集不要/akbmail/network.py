from __future__ import annotations

import socket


def local_ipv4_addresses() -> list[str]:
    found: set[str] = set()
    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
        found.update(info[4][0] for info in infos)
    except OSError:
        pass
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.2)
        sock.connect(("192.0.2.1", 80))
        found.add(sock.getsockname()[0])
        sock.close()
    except OSError:
        pass
    return sorted(ip for ip in found if not ip.startswith("127."))


def first_local_ipv4() -> str:
    addresses = local_ipv4_addresses()
    return addresses[0] if addresses else "（IPアドレスを取得できませんでした）"

