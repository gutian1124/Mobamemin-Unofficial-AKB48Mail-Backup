from __future__ import annotations

import ctypes
import os


class PreventSleep:
    """Keep Windows awake while a backup is active, then restore the prior policy."""

    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001

    def __enter__(self) -> "PreventSleep":
        if os.name == "nt":
            result = ctypes.windll.kernel32.SetThreadExecutionState(
                self.ES_CONTINUOUS | self.ES_SYSTEM_REQUIRED
            )
            if not result:
                raise ctypes.WinError()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if os.name == "nt":
            ctypes.windll.kernel32.SetThreadExecutionState(self.ES_CONTINUOUS)
