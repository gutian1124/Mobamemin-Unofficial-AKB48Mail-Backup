"""mitmproxy addon: capture only AKB48 Mail request metadata needed for backup."""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from mitmproxy import http

INTERNAL = Path(__file__).resolve().parent
sys.path.insert(0, str(INTERNAL))
from akbmail.security import save_secret_json


OUTPUT = Path(os.environ["AKBMAIL_CAPTURE_PATH"])
captured: dict[str, object] = {"version": 1}


def request(flow: http.HTTPFlow) -> None:
    host = flow.request.pretty_host.lower()
    path = flow.request.path.split("?", 1)[0]
    kind: str | None = None
    if host == "api.akb48mail-appli.com" and path == "/v1/inbox":
        kind = "list"
    elif host == "web.akb48mail-appli.com" and path.startswith("/mail/"):
        kind = "detail"
    elif host == "img.akb48mail-appli.com" and path.startswith("/artist/mail/"):
        kind = "image"
    if kind is None:
        return

    headers = [[str(name), str(value)] for name, value in flow.request.headers.items(multi=True)]
    captured[kind] = {
        "method": flow.request.method,
        "url": flow.request.pretty_url,
        "headers": headers,
        "captured_at": datetime.now(timezone.utc).isoformat(),
    }
    captured["updated_at"] = datetime.now(timezone.utc).isoformat()
    save_secret_json(OUTPUT, captured)
    # Never print URLs or header values: both may contain account information.
    logging.info("AKB48 Mail %s request captured (%d headers)", kind, len(headers))
