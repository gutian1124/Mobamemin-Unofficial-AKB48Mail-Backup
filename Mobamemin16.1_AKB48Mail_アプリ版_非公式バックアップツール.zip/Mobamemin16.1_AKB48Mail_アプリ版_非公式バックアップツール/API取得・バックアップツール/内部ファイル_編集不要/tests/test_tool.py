from __future__ import annotations

import importlib.util
import os
import sys
import sqlite3
import tempfile
import threading
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

INTERNAL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(INTERNAL))

from akbmail.api import captured_headers, extract_detail, url_with_page
from akbmail.backup import BackupOptions, BackupRunner
from akbmail.capture import (
    clean_proxy_line,
    is_benign_connection_reset,
    proxy_environment,
    should_display_proxy_line,
    CaptureManager,
)
from akbmail.security import load_secret_json, save_secret_json
from akbmail.storage import SCHEMA, Storage


CAPTURE = {
    "version": 1,
    "list": {
        "url": "https://api.akb48mail-appli.com/v1/inbox?is_information=0&is_star=0&is_unread=0&page=1",
        "headers": [
            ["Accept", "*/*"],
            ["Application-Version", "1.4.8"],
            ["User-Id", "test-user"],
            ["Access-Token", "test-token"],
            ["If-None-Match", "cached"],
            ["Device-Version", "iPhone17,2"],
        ],
    },
    "detail": {
        "url": "https://web.akb48mail-appli.com/mail/m1",
        "headers": [["User-Id", "test-user"], ["Access-Token", "test-token"]],
    },
    "image": {
        "url": "https://img.akb48mail-appli.com/artist/mail/akb/1/a.jpg",
        "headers": [["Accept", "image/*"], ["User-Agent", "iPhone test"]],
    },
}


DETAIL = """<!doctype html><html><body><main><div id="mail-detail">
こんにちは<br>テスト本文<script>alert(1)</script>
<div class="select-image-area"><img src="https://img.akb48mail-appli.com/artist/mail/akb/1/a.jpg" onerror="bad()"></div>
またね
</div></main></body></html>"""


def mail(mail_id: str, member: str, when: str, image: bool = False) -> dict:
    return {
        "id": mail_id,
        "member": {"id": 1, "name": member},
        "group": {"id": 1, "name": "AKB48"},
        "subject": f"件名 {mail_id}",
        "content": "本文プレビュー",
        "receive_datetime": when,
        "detail_url": f"https://web.akb48mail-appli.com/mail/{mail_id}",
        "is_image": image,
        "is_star": False,
    }


class FakeClient:
    detail_calls = 0
    image_calls = 0

    def __init__(self, capture, stop_event=None, log=None):
        self.stop_event = stop_event

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return None

    def get_list(self, page: int):
        pages = {
            1: {"page": 1, "has_next_page": True, "mails": [mail("m2", "長友彩海", "2026-08-26 17:05:05", True)]},
            2: {"page": 2, "has_next_page": False, "mails": [mail("m1", "テスト花子", "2026-08-25 12:00:00")]},
        }
        return pages[page]

    def get_detail(self, url: str):
        type(self).detail_calls += 1
        return DETAIL

    def get_image(self, url: str):
        type(self).image_calls += 1
        return b"fake-jpeg", "image/jpeg"


class ApiParsingTests(unittest.TestCase):
    def test_page_replacement_preserves_other_query(self):
        changed = url_with_page(CAPTURE["list"]["url"], 42)
        self.assertIn("is_information=0", changed)
        self.assertIn("is_unread=0", changed)
        self.assertIn("page=42", changed)

    def test_only_conditional_headers_are_removed(self):
        headers = captured_headers(CAPTURE["list"])
        self.assertNotIn("If-None-Match", headers)
        self.assertEqual(headers["Application-Version"], "1.4.8")
        self.assertEqual(headers["Device-Version"], "iPhone17,2")

    def test_detail_extracts_text_images_and_removes_script(self):
        detail = extract_detail(DETAIL, "https://web.akb48mail-appli.com/mail/m1")
        self.assertIn("こんにちは", detail.text)
        self.assertEqual(len(detail.image_urls), 1)
        self.assertNotIn("script", detail.safe_html.lower())
        self.assertNotIn("onerror", detail.safe_html.lower())
        self.assertIn("画像 1", detail.safe_html)

    def test_unsupported_image_does_not_shift_saved_image_marker(self):
        document = """<div id="mail-detail">
        前<img src="https://unexpected.example/not-saved.jpg">
        中<img src="https://img.akb48mail-appli.com/artist/mail/akb/saved.jpg">後
        </div>"""
        detail = extract_detail(document, "https://web.akb48mail-appli.com/mail/m1")
        self.assertEqual(
            detail.image_urls,
            ["https://img.akb48mail-appli.com/artist/mail/akb/saved.jpg"],
        )
        self.assertEqual(detail.safe_html.count('class="image-marker"'), 1)
        self.assertIn("保存対象外の画像", detail.safe_html)
        self.assertIn("画像 1", detail.safe_html)


class CaptureLogTests(unittest.TestCase):
    def test_child_output_is_forced_to_utf8(self):
        environment = proxy_environment({"TASK_TEST": "kept"})
        self.assertEqual(environment["TASK_TEST"], "kept")
        self.assertEqual(environment["PYTHONUTF8"], "1")
        self.assertEqual(environment["PYTHONIOENCODING"], "utf-8:replace")

    def test_reset_noise_is_hidden_but_actionable_errors_remain(self):
        reset = "ConnectionResetError: [WinError 10054] connection was forcibly closed"
        self.assertTrue(is_benign_connection_reset(reset))
        self.assertFalse(should_display_proxy_line(reset))
        self.assertFalse(should_display_proxy_line("Error in server connection"))
        self.assertTrue(should_display_proxy_line("Client TLS handshake failed"))
        self.assertTrue(should_display_proxy_line("AKB48 Mail detail request captured"))

    def test_ansi_control_sequences_are_removed(self):
        self.assertEqual(clean_proxy_line("\x1b[31mfailed to start\x1b[0m\r\n"), "failed to start")

    def test_current_capture_session_is_distinguished_from_previous_data(self):
        with tempfile.TemporaryDirectory() as temporary:
            manager = CaptureManager(Path(temporary))
            manager.session_started_at = datetime.now(timezone.utc)
            previous = {
                "captured_at": (manager.session_started_at - timedelta(seconds=1)).isoformat()
            }
            current = {
                "captured_at": (manager.session_started_at + timedelta(seconds=1)).isoformat()
            }
            self.assertFalse(manager.is_current_session_item(previous))
            self.assertTrue(manager.is_current_session_item(current))


class EndToEndTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.data_dir = Path(self.temp.name) / "data"
        self.storage = Storage(self.data_dir)
        FakeClient.detail_calls = 0
        FakeClient.image_calls = 0

    def tearDown(self):
        self.temp.cleanup()

    @patch("akbmail.backup.AkbMailClient", FakeClient)
    def test_backup_resume(self):
        runner = BackupRunner(
            self.storage,
            CAPTURE,
            BackupOptions(limit=None, request_interval=0),
            threading.Event(),
            lambda message: None,
        )
        first = runner.run()
        self.assertEqual(first.listed, 2)
        self.assertEqual(first.details_completed, 2)
        self.assertEqual(first.images_completed, 2)
        self.assertEqual(FakeClient.detail_calls, 2)

        second = runner.run()
        self.assertEqual(second.details_completed, 0)
        self.assertEqual(second.details_skipped, 2)
        self.assertEqual(second.images_skipped, 2)
        self.assertEqual(FakeClient.detail_calls, 2, "resume must not fetch completed details")

    def test_duplicate_image_positions_and_image_errors_are_counted(self):
        self.storage.upsert_mails(
            [mail("duplicate", "テスト花子", "2026-08-29 09:00:00", True)]
        )
        url = "https://img.akb48mail-appli.com/artist/mail/akb/same.jpg"
        self.storage.upsert_images("duplicate", [url, url])
        images = self.storage.images_for_mail("duplicate")
        self.assertEqual([row["position"] for row in images], [0, 1])
        self.storage.mark_image_error(int(images[0]["id"]), "forced error")
        missing_path = self.storage.image_dir / "duplicate" / "missing.jpg"
        self.storage.mark_image_complete(int(images[1]["id"]), missing_path, "image/jpeg")
        counts = self.storage.counts()
        self.assertEqual(counts["image_errors"], 1)
        self.assertEqual(counts["image_missing"], 1)
        self.assertEqual(counts["errors"], 2)

    def test_legacy_image_schema_is_migrated(self):
        with tempfile.TemporaryDirectory() as temporary:
            data_dir = Path(temporary) / "legacy"
            data_dir.mkdir()
            db_path = data_dir / "mail.sqlite3"
            legacy_schema = SCHEMA.replace(
                "UNIQUE(mail_id, position)", "UNIQUE(mail_id, url)"
            )
            conn = sqlite3.connect(db_path)
            try:
                conn.executescript(legacy_schema)
                conn.execute(
                    "INSERT INTO mails(id, detail_url, raw_list_json) VALUES(?, ?, ?)",
                    ("legacy", "https://web.akb48mail-appli.com/mail/legacy", "{}"),
                )
                conn.execute(
                    "INSERT INTO images(mail_id, position, url) VALUES(?, ?, ?)",
                    ("legacy", 0, "https://img.akb48mail-appli.com/artist/mail/old.jpg"),
                )
                conn.commit()
            finally:
                conn.close()
            storage = Storage(data_dir)
            same = "https://img.akb48mail-appli.com/artist/mail/same.jpg"
            storage.upsert_images("legacy", [same, same])
            self.assertEqual(len(storage.images_for_mail("legacy")), 2)

    def test_secret_round_trip(self):
        path = Path(self.temp.name) / "secret.dat"
        save_secret_json(path, {"token": "秘密", "nested": {"n": 1}})
        self.assertNotIn("秘密".encode("utf-8"), path.read_bytes())
        self.assertEqual(load_secret_json(path)["token"], "秘密")

    def test_capture_addon_writes_dpapi_file_without_plaintext_handoff(self):
        path = Path(self.temp.name) / "captured.dat"

        class FakeHeaders:
            def items(self, multi=False):
                self.multi = multi
                return [("Access-Token", "plain-secret-token"), ("Accept", "*/*")]

        request = SimpleNamespace(
            pretty_host="api.akb48mail-appli.com",
            path="/v1/inbox?page=1",
            method="GET",
            pretty_url="https://api.akb48mail-appli.com/v1/inbox?page=1",
            headers=FakeHeaders(),
        )
        flow = SimpleNamespace(request=request)
        addon_path = INTERNAL / "capture_addon.py"
        spec = importlib.util.spec_from_file_location("akbmail_test_capture_addon", addon_path)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        with patch.dict(os.environ, {"AKBMAIL_CAPTURE_PATH": str(path)}):
            spec.loader.exec_module(module)
            module.request(flow)

        self.assertNotIn(b"plain-secret-token", path.read_bytes())
        saved = load_secret_json(path)
        self.assertIn("list", saved)
        self.assertEqual(saved["list"]["headers"][0][1], "plain-secret-token")


if __name__ == "__main__":
    unittest.main(verbosity=2)
