from __future__ import annotations

import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INTERNAL = ROOT / "内部ファイル_編集不要"
sys.path.insert(0, str(INTERNAL))


def main() -> int:
    if sys.version_info < (3, 12):
        raise RuntimeError("Python 3.12 以降が必要です。初回セットアップをやり直してください。")
    from akbviewer.gui import run_app

    run_app(ROOT, ROOT.parent / "バックアップデータ")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        try:
            input("\n予期しないエラーが発生しました。Enterキーで閉じます...")
        except EOFError:
            pass
        raise SystemExit(1)
