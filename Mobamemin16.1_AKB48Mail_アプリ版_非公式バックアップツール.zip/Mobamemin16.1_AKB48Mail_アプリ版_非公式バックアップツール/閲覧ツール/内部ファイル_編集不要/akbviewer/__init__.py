"""Local viewer for AKB48 Mail backup data."""

__version__ = "16.1"
