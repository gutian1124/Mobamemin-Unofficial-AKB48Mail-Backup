from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .storage import Storage
from .viewer import ViewerServer


class ViewerApp:
    def __init__(self, root: tk.Tk, app_root: Path, default_data_dir: Path):
        self.root = root
        self.app_root = app_root
        self.default_data_dir = default_data_dir.resolve()
        self.state_dir = app_root / "内部ファイル_編集不要" / "状態"
        self.config_path = self.state_dir / "viewer_config.json"
        self.storage: Storage | None = None
        self.viewer: ViewerServer | None = None
        self.data_dir = self._load_data_dir()

        self.root.title("AKB48 Mail 閲覧ツール")
        self.root.geometry("900x460")
        self.root.minsize(720, 400)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._configure_style()
        self._build_ui()
        self._activate_data_dir(self.data_dir, persist=False)

    def _configure_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Yu Gothic UI", 18, "bold"))
        style.configure("Heading.TLabel", font=("Yu Gothic UI", 11, "bold"))
        style.configure("Accent.TButton", font=("Yu Gothic UI", 10, "bold"))

    def _build_ui(self) -> None:
        frame = ttk.Frame(self.root, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="AKB48 Mail 閲覧ツール", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            frame,
            text=(
                "保存済みメールをPC内だけで検索・閲覧します。AKB48 Mailへの通信、"
                "iPhone通信取得、バックアップ処理は行いません。"
            ),
            wraplength=850,
        ).pack(anchor="w", pady=(4, 18))

        location = ttk.LabelFrame(frame, text="使用するバックアップデータ", padding=12)
        location.pack(fill="x")
        self.path_var = tk.StringVar()
        ttk.Label(location, textvariable=self.path_var, wraplength=820).pack(anchor="w")
        location_buttons = ttk.Frame(location)
        location_buttons.pack(anchor="w", pady=(10, 0))
        ttk.Button(
            location_buttons,
            text="別のバックアップデータを選択",
            command=self._choose_data_dir,
        ).pack(side="left")
        ttk.Button(
            location_buttons,
            text="標準の共有フォルダーに戻す",
            command=self._use_default_data_dir,
        ).pack(side="left", padx=8)

        status = ttk.LabelFrame(frame, text="保存状況", padding=12)
        status.pack(fill="x", pady=14)
        self.counts_var = tk.StringVar(value="確認中...")
        ttk.Label(
            status,
            textvariable=self.counts_var,
            font=("Yu Gothic UI", 11, "bold"),
            justify="left",
        ).pack(side="left", anchor="w")
        ttk.Button(status, text="保存状況を更新", command=self._refresh_counts).pack(
            side="right", padx=(12, 0)
        )

        controls = ttk.Frame(frame)
        controls.pack(fill="x", pady=(2, 0))
        ttk.Button(
            controls,
            text="検索・閲覧ページを開く",
            style="Accent.TButton",
            command=self._open_viewer,
        ).pack(side="left")
        self.viewer_url_var = tk.StringVar()
        ttk.Label(controls, textvariable=self.viewer_url_var).pack(side="left", padx=12)
        ttk.Label(
            frame,
            text=(
                "お気に入りは選択中のバックアップDBだけに保存され、サービス側は変更しません。"
                "閲覧ツールを終了するとローカル閲覧ページも停止します。"
            ),
            wraplength=850,
        ).pack(anchor="w", pady=(18, 0))

    def _load_data_dir(self) -> Path:
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
            saved = payload.get("data_dir") if isinstance(payload, dict) else None
            if isinstance(saved, str) and saved.strip():
                candidate = Path(saved).expanduser().resolve()
                if candidate.is_dir():
                    return candidate
        except (OSError, ValueError, TypeError):
            pass
        return self.default_data_dir

    def _save_data_dir(self, data_dir: Path) -> None:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        temporary = self.config_path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps({"data_dir": str(data_dir)}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(self.config_path)

    def _activate_data_dir(self, data_dir: Path, persist: bool = True) -> None:
        resolved = data_dir.expanduser().resolve()
        resolved.mkdir(parents=True, exist_ok=True)
        if self.viewer is not None:
            self.viewer.stop()
        self.data_dir = resolved
        self.storage = Storage(resolved)
        self.viewer = ViewerServer(self.storage)
        self.viewer_url_var.set("")
        self.path_var.set(str(resolved))
        if persist:
            self._save_data_dir(resolved)
        self._refresh_counts()

    def _choose_data_dir(self) -> None:
        selected = filedialog.askdirectory(
            title="バックアップデータフォルダーを選択",
            initialdir=str(self.data_dir),
            mustexist=True,
            parent=self.root,
        )
        if not selected:
            return
        candidate = Path(selected)
        if not (candidate / "mail.sqlite3").is_file():
            proceed = messagebox.askyesno(
                "バックアップDBが見つかりません",
                "選択したフォルダーには mail.sqlite3 がありません。\n"
                "空の閲覧データとして使用しますか？",
                parent=self.root,
            )
            if not proceed:
                return
        try:
            self._activate_data_dir(candidate)
        except Exception as exc:
            messagebox.showerror("フォルダーを使用できません", str(exc), parent=self.root)

    def _use_default_data_dir(self) -> None:
        try:
            self._activate_data_dir(self.default_data_dir)
        except Exception as exc:
            messagebox.showerror("標準フォルダーを使用できません", str(exc), parent=self.root)

    def _refresh_counts(self) -> None:
        if self.storage is None:
            return
        try:
            counts = self.storage.counts()
            self.counts_var.set(
                f"一覧 {counts['total']}件　本文 完了{counts['complete']} / "
                f"未処理{counts['detail_pending']} / エラー{counts['detail_errors']}\n"
                f"画像 対象{counts['image_total']}　完了{counts['image_complete']} / "
                f"未処理{counts['image_pending']} / エラー{counts['image_errors']} / "
                f"ファイル欠損{counts['image_missing']}"
            )
        except Exception as exc:
            self.counts_var.set(f"保存状況を読めません: {exc}")

    def _open_viewer(self) -> None:
        if self.viewer is None:
            return
        try:
            url = self.viewer.start(open_browser=True)
            self.viewer_url_var.set(f"閲覧ページ: {url}")
            self._refresh_counts()
        except Exception as exc:
            messagebox.showerror("閲覧ページを開けません", str(exc), parent=self.root)

    def _on_close(self) -> None:
        if self.viewer is not None:
            self.viewer.stop()
        self.root.destroy()


def run_app(app_root: Path, default_data_dir: Path) -> None:
    root = tk.Tk()
    ViewerApp(root, app_root, default_data_dir)
    root.mainloop()
