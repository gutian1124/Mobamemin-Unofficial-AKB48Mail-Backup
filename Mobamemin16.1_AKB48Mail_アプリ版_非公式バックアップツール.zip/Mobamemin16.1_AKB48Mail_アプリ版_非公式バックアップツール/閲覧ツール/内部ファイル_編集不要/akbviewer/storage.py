from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS mails (
    id TEXT PRIMARY KEY,
    member_id INTEGER,
    member_name TEXT NOT NULL DEFAULT '',
    group_name TEXT NOT NULL DEFAULT '',
    subject TEXT NOT NULL DEFAULT '',
    content_preview TEXT NOT NULL DEFAULT '',
    receive_datetime TEXT NOT NULL DEFAULT '',
    detail_url TEXT NOT NULL,
    is_image INTEGER NOT NULL DEFAULT 0,
    is_star INTEGER NOT NULL DEFAULT 0,
    raw_list_json TEXT NOT NULL,
    detail_status TEXT NOT NULL DEFAULT 'pending',
    detail_html_path TEXT,
    body_text TEXT,
    body_html TEXT,
    error TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mails_datetime ON mails(receive_datetime DESC);
CREATE INDEX IF NOT EXISTS idx_mails_member ON mails(member_name);
CREATE INDEX IF NOT EXISTS idx_mails_status ON mails(detail_status);
CREATE TABLE IF NOT EXISTS images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mail_id TEXT NOT NULL REFERENCES mails(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    url TEXT NOT NULL,
    local_path TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    content_type TEXT,
    error TEXT,
    UNIQUE(mail_id, position)
);
CREATE INDEX IF NOT EXISTS idx_images_mail ON images(mail_id, position);
CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS viewer_favorites (
    mail_id TEXT PRIMARY KEY REFERENCES mails(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


class Storage:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "mail.sqlite3"
        self.raw_list_dir = self.data_dir / "raw" / "lists"
        self.raw_detail_dir = self.data_dir / "raw" / "details"
        self.image_dir = self.data_dir / "images"
        for directory in (self.raw_list_dir, self.raw_detail_dir, self.image_dir):
            directory.mkdir(parents=True, exist_ok=True)
        with self.connect() as conn:
            conn.executescript(SCHEMA)
            self._migrate_legacy_images_schema(conn)

    def _migrate_legacy_images_schema(self, conn: sqlite3.Connection) -> None:
        """Replace the pre-1.1 image URL uniqueness rule without losing progress."""
        legacy_unique_url = False
        for index in conn.execute("PRAGMA index_list(images)"):
            if not index["unique"]:
                continue
            name = str(index["name"]).replace('"', '""')
            columns = [
                row["name"] for row in conn.execute(f'PRAGMA index_info("{name}")')
            ]
            if columns == ["mail_id", "url"]:
                legacy_unique_url = True
                break
        if not legacy_unique_url:
            return

        rows = list(conn.execute("SELECT * FROM images ORDER BY id"))
        conn.execute("DROP INDEX IF EXISTS idx_images_mail")
        conn.execute("ALTER TABLE images RENAME TO images_legacy")
        conn.execute(
            """
            CREATE TABLE images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mail_id TEXT NOT NULL REFERENCES mails(id) ON DELETE CASCADE,
                position INTEGER NOT NULL,
                url TEXT NOT NULL,
                local_path TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                content_type TEXT,
                error TEXT,
                UNIQUE(mail_id, position)
            )
            """
        )
        for row in rows:
            existing = conn.execute(
                "SELECT id, status FROM images WHERE mail_id=? AND position=?",
                (row["mail_id"], row["position"]),
            ).fetchone()
            if existing is None:
                conn.execute(
                    """
                    INSERT INTO images(
                        id, mail_id, position, url, local_path, status, content_type, error
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    tuple(row),
                )
            elif existing["status"] != "complete" and row["status"] == "complete":
                conn.execute(
                    """
                    UPDATE images SET url=?, local_path=?, status=?, content_type=?, error=?
                    WHERE id=?
                    """,
                    (
                        row["url"],
                        row["local_path"],
                        row["status"],
                        row["content_type"],
                        row["error"],
                        existing["id"],
                    ),
                )
        conn.execute("DROP TABLE images_legacy")
        conn.execute("CREATE INDEX idx_images_mail ON images(mail_id, position)")

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def set_metadata(self, key: str, value: Any) -> None:
        encoded = json.dumps(value, ensure_ascii=False)
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO metadata(key, value) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, encoded),
            )

    def get_metadata(self, key: str, default: Any = None) -> Any:
        with self.connect() as conn:
            row = conn.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        return default if row is None else json.loads(row["value"])

    def save_raw_list(self, page: int, payload: dict[str, Any]) -> Path:
        path = self.raw_list_dir / f"page_{page:06d}.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def save_raw_detail(self, mail_id: str, html: str) -> Path:
        path = self.raw_detail_dir / f"{safe_component(mail_id)}.html"
        path.write_text(html, encoding="utf-8")
        return path

    def upsert_mails(self, mails: Iterable[dict[str, Any]]) -> int:
        rows = []
        for mail in mails:
            member = mail.get("member") or {}
            group = mail.get("group") or {}
            mail_id = str(mail.get("id") or "").strip()
            detail_url = str(mail.get("detail_url") or "").strip()
            if not mail_id or not detail_url:
                continue
            rows.append(
                (
                    mail_id,
                    member.get("id"),
                    str(member.get("name") or ""),
                    str(group.get("name") or ""),
                    str(mail.get("subject") or ""),
                    str(mail.get("content") or ""),
                    str(mail.get("receive_datetime") or ""),
                    detail_url,
                    int(bool(mail.get("is_image"))),
                    int(bool(mail.get("is_star"))),
                    json.dumps(mail, ensure_ascii=False),
                )
            )
        with self.connect() as conn:
            conn.executemany(
                """
                INSERT INTO mails(
                    id, member_id, member_name, group_name, subject, content_preview,
                    receive_datetime, detail_url, is_image, is_star, raw_list_json
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    member_id=excluded.member_id,
                    member_name=excluded.member_name,
                    group_name=excluded.group_name,
                    subject=excluded.subject,
                    content_preview=excluded.content_preview,
                    receive_datetime=excluded.receive_datetime,
                    detail_url=excluded.detail_url,
                    is_image=excluded.is_image,
                    is_star=excluded.is_star,
                    raw_list_json=excluded.raw_list_json,
                    updated_at=CURRENT_TIMESTAMP
                """,
                rows,
            )
        return len(rows)

    def selected_mails(self, limit: int | None) -> list[sqlite3.Row]:
        sql = "SELECT * FROM mails ORDER BY receive_datetime DESC, id DESC"
        params: tuple[Any, ...] = ()
        if limit is not None:
            sql += " LIMIT ?"
            params = (limit,)
        with self.connect() as conn:
            return list(conn.execute(sql, params))

    def set_viewer_favorite(self, mail_id: str, favorite: bool) -> bool:
        """Persist a PC-local favorite without changing the service-side is_star flag."""
        with self.connect() as conn:
            exists = conn.execute("SELECT 1 FROM mails WHERE id=?", (mail_id,)).fetchone()
            if exists is None:
                return False
            if favorite:
                conn.execute(
                    "INSERT OR IGNORE INTO viewer_favorites(mail_id) VALUES(?)",
                    (mail_id,),
                )
            else:
                conn.execute("DELETE FROM viewer_favorites WHERE mail_id=?", (mail_id,))
        return True

    def is_viewer_favorite(self, mail_id: str) -> bool:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM viewer_favorites WHERE mail_id=?", (mail_id,)
            ).fetchone()
        return row is not None

    def mark_detail_complete(
        self,
        mail_id: str,
        raw_path: Path,
        body_text: str,
        body_html: str,
    ) -> None:
        relative = raw_path.relative_to(self.data_dir).as_posix()
        with self.connect() as conn:
            conn.execute(
                """
                UPDATE mails SET detail_status='complete', detail_html_path=?,
                    body_text=?, body_html=?, error=NULL, updated_at=CURRENT_TIMESTAMP
                WHERE id=?
                """,
                (relative, body_text, body_html, mail_id),
            )

    def mark_detail_error(self, mail_id: str, message: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE mails SET detail_status='error', error=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (message[:2000], mail_id),
            )

    def upsert_images(self, mail_id: str, urls: list[str]) -> None:
        with self.connect() as conn:
            conn.executemany(
                """
                INSERT INTO images(mail_id, position, url) VALUES(?, ?, ?)
                ON CONFLICT(mail_id, position) DO UPDATE SET
                    url=excluded.url,
                    local_path=CASE WHEN images.url=excluded.url THEN images.local_path ELSE NULL END,
                    status=CASE WHEN images.url=excluded.url THEN images.status ELSE 'pending' END,
                    content_type=CASE WHEN images.url=excluded.url THEN images.content_type ELSE NULL END,
                    error=CASE WHEN images.url=excluded.url THEN images.error ELSE NULL END
                """,
                [(mail_id, index, url) for index, url in enumerate(urls)],
            )
            conn.execute(
                "DELETE FROM images WHERE mail_id=? AND position>=?",
                (mail_id, len(urls)),
            )

    def images_for_mail(self, mail_id: str) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(
                conn.execute(
                    "SELECT * FROM images WHERE mail_id=? ORDER BY position", (mail_id,)
                )
            )

    def mark_image_complete(
        self, image_id: int, local_path: Path, content_type: str | None
    ) -> None:
        relative = local_path.relative_to(self.data_dir).as_posix()
        with self.connect() as conn:
            conn.execute(
                "UPDATE images SET status='complete', local_path=?, content_type=?, error=NULL WHERE id=?",
                (relative, content_type, image_id),
            )

    def mark_image_error(self, image_id: int, message: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE images SET status='error', error=? WHERE id=?",
                (message[:2000], image_id),
            )

    def counts(self) -> dict[str, int]:
        with self.connect() as conn:
            mail_row = conn.execute(
                """
                SELECT COUNT(*) AS total,
                       SUM(detail_status='complete') AS complete,
                       SUM(detail_status='error') AS errors,
                       SUM(detail_status NOT IN ('complete', 'error')) AS pending
                FROM mails
                """
            ).fetchone()
            image_row = conn.execute(
                """
                SELECT COUNT(*) AS total,
                       SUM(status='complete') AS complete,
                       SUM(status='error') AS errors,
                       SUM(status NOT IN ('complete', 'error')) AS pending
                FROM images
                """
            ).fetchone()
            completed_images = list(
                conn.execute("SELECT local_path FROM images WHERE status='complete'")
            )

        image_missing = 0
        data_root = self.data_dir.resolve()
        for image in completed_images:
            relative = str(image["local_path"] or "")
            path = (self.data_dir / relative).resolve() if relative else None
            try:
                healthy = (
                    path is not None
                    and path.is_relative_to(data_root)
                    and path.is_file()
                    and path.stat().st_size > 0
                )
            except OSError:
                healthy = False
            if not healthy:
                image_missing += 1

        detail_errors = int(mail_row["errors"] or 0)
        image_errors = int(image_row["errors"] or 0)
        result = {
            "total": int(mail_row["total"] or 0),
            "complete": int(mail_row["complete"] or 0),
            "detail_errors": detail_errors,
            "detail_pending": int(mail_row["pending"] or 0),
            "image_total": int(image_row["total"] or 0),
            "image_complete": max(0, int(image_row["complete"] or 0) - image_missing),
            "image_errors": image_errors,
            "image_pending": int(image_row["pending"] or 0),
            "image_missing": image_missing,
        }
        result["errors"] = detail_errors + image_errors + image_missing
        return result


def safe_component(value: str) -> str:
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    cleaned = "".join(char if char in allowed else "_" for char in value)
    return cleaned[:100] or "item"
