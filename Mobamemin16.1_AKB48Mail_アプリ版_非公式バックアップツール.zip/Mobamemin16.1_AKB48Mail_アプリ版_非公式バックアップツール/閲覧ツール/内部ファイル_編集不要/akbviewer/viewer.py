from __future__ import annotations

import html
import re
import secrets
import sqlite3
import threading
import webbrowser
from pathlib import Path

from bs4 import BeautifulSoup
from flask import Flask, abort, make_response, redirect, render_template_string, request, send_file, url_for
from markupsafe import Markup
from werkzeug.serving import BaseWSGIServer, make_server

from .storage import Storage


BASE_STYLE = """
:root { color-scheme: light; --pink:#d81b60; --ink:#25212a; --muted:#756d78; --line:#e8dfe7; }
* { box-sizing:border-box; }
body { margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Yu Gothic UI",sans-serif; color:var(--ink); background:#faf8fa; }
header { background:linear-gradient(120deg,#b5114c,#ef5d91); color:white; padding:18px 24px; }
header h1 { margin:0; font-size:22px; }
header p { margin:5px 0 0; opacity:.9; font-size:13px; }
main { max-width:1180px; margin:0 auto; padding:20px; }
.panel { background:white; border:1px solid var(--line); border-radius:12px; box-shadow:0 3px 14px #5e24400b; }
.filters { display:grid; grid-template-columns:2fr 1fr 1fr 1fr 1fr 1fr auto; gap:10px; padding:14px; margin-bottom:16px; }
input,select,button { min-height:39px; border:1px solid #cfc4cd; border-radius:8px; padding:7px 10px; font:inherit; background:white; }
button { background:var(--pink); color:white; border-color:var(--pink); cursor:pointer; font-weight:600; }
.favorite-form { display:inline-block; margin:0; }
.favorite-button { min-height:32px; padding:4px 9px; white-space:nowrap; }
.favorite-button.off { background:white; color:var(--pink); }
table { width:100%; border-collapse:collapse; }
th,td { padding:11px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }
th { color:var(--muted); font-size:12px; background:#fffafd; position:sticky; top:0; }
td { font-size:14px; }
tr:last-child td { border-bottom:0; }
a { color:#b5114c; text-decoration:none; }
a:hover { text-decoration:underline; }
.subject { font-weight:650; }
.preview { color:var(--muted); font-size:12px; margin-top:4px; max-width:600px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.badge { display:inline-block; background:#f9dce7; color:#9c1746; padding:2px 7px; border-radius:999px; font-size:11px; }
.pager { display:flex; justify-content:space-between; align-items:center; margin-top:14px; }
.mail-head { padding:20px 22px; border-bottom:1px solid var(--line); }
.mail-head h2 { margin:6px 0; font-size:24px; }
.meta { color:var(--muted); font-size:13px; }
.body { padding:24px; font-size:16px; line-height:1.85; overflow-wrap:anywhere; }
.image-marker { display:block; color:var(--muted); font-size:12px; margin:8px 0; }
.mail-inline-image-link { display:block; margin:16px 0; }
.mail-inline-image { display:block; max-width:100%; width:auto; height:auto; border-radius:9px; background:#eee; }
.gallery { display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:14px; padding:0 24px 24px; }
.gallery img { width:100%; height:auto; display:block; border-radius:9px; background:#eee; }
.back { display:inline-block; margin-bottom:14px; }
.back-bottom { margin:14px 0 0; }
.empty { padding:50px; text-align:center; color:var(--muted); }
@media(max-width:800px){ .filters{grid-template-columns:1fr 1fr}.filters input:first-child{grid-column:1/-1} th:nth-child(3),td:nth-child(3){display:none} }
"""


LIST_TEMPLATE = """
<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AKB48 Mail 閲覧ツール</title><style>{{ style|safe }}</style></head>
<body><header><h1>AKB48 Mail 閲覧ツール</h1><p>保存済みデータだけを表示しています（AKB48 Mailへの通信は行いません）</p></header><main>
<form class="panel filters" method="get">
  <input name="q" value="{{ filters.q }}" placeholder="件名・本文・メンバーを検索">
  <select name="member"><option value="">すべてのメンバー</option>{% for member in members %}<option value="{{ member }}" {% if filters.member == member %}selected{% endif %}>{{ member }}</option>{% endfor %}</select>
  <input type="date" name="date_from" value="{{ filters.date_from }}" title="開始日">
  <input type="date" name="date_to" value="{{ filters.date_to }}" title="終了日">
  <select name="has_image"><option value="" {% if not filters.has_image %}selected{% endif %}>画像：すべて</option><option value="yes" {% if filters.has_image=='yes' %}selected{% endif %}>画像あり</option><option value="no" {% if filters.has_image=='no' %}selected{% endif %}>画像なし</option></select>
  <select name="favorite"><option value="" {% if not filters.favorite %}selected{% endif %}>お気に入り：すべて</option><option value="yes" {% if filters.favorite=='yes' %}selected{% endif %}>お気に入りのみ</option></select>
  <button>検索</button>
</form>
<section class="panel">{% if rows %}<table><thead><tr><th>日時</th><th>メンバー</th><th>メール</th><th>画像</th><th>お気に入り</th></tr></thead><tbody>
{% for row in rows %}<tr><td>{{ row.receive_datetime }}</td><td>{{ row.member_name }}</td><td><a class="subject" href="{{ url_for('mail_detail', mail_id=row.id, return_to=current_url) }}">{{ row.subject or '（件名なし）' }}</a><div class="preview">{{ row.content_preview }}</div></td><td>{% if row.image_count %}<span class="badge">{{ row.image_count }}枚</span>{% endif %}</td><td><form class="favorite-form" method="post" action="{{ url_for('set_favorite', mail_id=row.id) }}"><input type="hidden" name="token" value="{{ favorite_token }}"><input type="hidden" name="next" value="{{ current_url }}"><input type="hidden" name="favorite" value="{{ 0 if row.local_favorite else 1 }}"><button class="favorite-button{% if not row.local_favorite %} off{% endif %}" type="submit">{% if row.local_favorite %}★ 解除{% else %}☆ 登録{% endif %}</button></form></td></tr>{% endfor %}
</tbody></table>{% else %}<div class="empty">条件に一致する保存済みメールがありません。</div>{% endif %}</section>
<div class="pager"><span>{{ total }}件中 {{ start }}–{{ end }}件</span><span>{% if page>1 %}<a href="{{ page_url(page-1) }}">← 前へ</a>{% endif %}　{% if end<total %}<a href="{{ page_url(page+1) }}">次へ →</a>{% endif %}</span></div>
</main></body></html>
"""


DETAIL_TEMPLATE = """
<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{ mail.subject }}</title><style>{{ style|safe }}</style></head>
<body><header><h1>AKB48 Mail 閲覧ツール</h1><p>オフライン保存データ</p></header><main><a class="back" href="{{ back_url }}">← 一覧へ戻る</a>
<article class="panel"><div class="mail-head"><div class="meta">{{ mail.receive_datetime }}　{{ mail.group_name }}</div><h2>{{ mail.subject or '（件名なし）' }}</h2><div>{{ mail.member_name }}</div><form class="favorite-form" method="post" action="{{ url_for('set_favorite', mail_id=mail.id) }}"><input type="hidden" name="token" value="{{ favorite_token }}"><input type="hidden" name="next" value="{{ current_url }}"><input type="hidden" name="favorite" value="{{ 0 if mail.local_favorite else 1 }}"><button class="favorite-button{% if not mail.local_favorite %} off{% endif %}" type="submit">{% if mail.local_favorite %}★ お気に入り解除{% else %}☆ お気に入り登録{% endif %}</button></form></div><div class="body">{{ body }}</div>
{% if remaining_images %}<div class="gallery">{% for image in remaining_images %}<a href="{{ url_for('saved_image', image_id=image.id) }}" target="_blank" rel="noopener"><img src="{{ url_for('saved_image', image_id=image.id) }}" alt="保存画像 {{ loop.index }}" loading="lazy"></a>{% endfor %}</div>{% endif %}</article>
<a class="back back-bottom" href="{{ back_url }}">← 一覧へ戻る</a>
</main></body></html>
"""


def create_viewer_app(storage: Storage) -> Flask:
    app = Flask(__name__)
    app.config.update(SECRET_KEY=None)
    favorite_token = secrets.token_urlsafe(32)

    @app.after_request
    def secure_headers(response):
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; "
            "base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/")
    def index():
        filters = {
            "q": request.args.get("q", "").strip(),
            "member": request.args.get("member", "").strip(),
            "date_from": request.args.get("date_from", "").strip(),
            "date_to": request.args.get("date_to", "").strip(),
            "has_image": request.args.get("has_image", "").strip(),
            "favorite": request.args.get("favorite", "").strip(),
        }
        try:
            page = max(1, int(request.args.get("page", "1")))
        except ValueError:
            page = 1
        per_page = 50
        where = ["m.detail_status='complete'"]
        params: list[object] = []
        if filters["q"]:
            where.append("(m.subject LIKE ? ESCAPE '\\' OR m.body_text LIKE ? ESCAPE '\\' OR m.member_name LIKE ? ESCAPE '\\')")
            term = f"%{_escape_like(filters['q'])}%"
            params.extend([term, term, term])
        if filters["member"]:
            where.append("m.member_name=?")
            params.append(filters["member"])
        if filters["date_from"]:
            where.append("substr(m.receive_datetime,1,10)>=?")
            params.append(filters["date_from"])
        if filters["date_to"]:
            where.append("substr(m.receive_datetime,1,10)<=?")
            params.append(filters["date_to"])
        if filters["has_image"] == "yes":
            where.append("EXISTS(SELECT 1 FROM images ix WHERE ix.mail_id=m.id AND ix.status='complete')")
        elif filters["has_image"] == "no":
            where.append("NOT EXISTS(SELECT 1 FROM images ix WHERE ix.mail_id=m.id AND ix.status='complete')")
        if filters["favorite"] == "yes":
            where.append("EXISTS(SELECT 1 FROM viewer_favorites vf WHERE vf.mail_id=m.id)")
        clause = " AND ".join(where)
        with storage.connect() as conn:
            total = int(conn.execute(f"SELECT COUNT(*) FROM mails m WHERE {clause}", params).fetchone()[0])
            rows = conn.execute(
                f"""SELECT m.*,
                (SELECT COUNT(*) FROM images ix WHERE ix.mail_id=m.id AND ix.status='complete') AS image_count,
                EXISTS(SELECT 1 FROM viewer_favorites vf WHERE vf.mail_id=m.id) AS local_favorite
                FROM mails m WHERE {clause} ORDER BY m.receive_datetime DESC, m.id DESC LIMIT ? OFFSET ?""",
                [*params, per_page, (page - 1) * per_page],
            ).fetchall()
            members = [row[0] for row in conn.execute("SELECT DISTINCT member_name FROM mails WHERE detail_status='complete' AND member_name<>'' ORDER BY member_name")]

        def page_url(number: int) -> str:
            arguments = {key: value for key, value in filters.items() if value}
            arguments["page"] = number
            return url_for("index", **arguments)

        start = 0 if total == 0 else (page - 1) * per_page + 1
        end = min(total, page * per_page)
        current_url = request.full_path.rstrip("?")
        return render_template_string(
            LIST_TEMPLATE,
            style=BASE_STYLE,
            rows=rows,
            total=total,
            start=start,
            end=end,
            page=page,
            filters=filters,
            members=members,
            page_url=page_url,
            current_url=current_url,
            favorite_token=favorite_token,
        )

    @app.get("/mail/<mail_id>")
    def mail_detail(mail_id: str):
        with storage.connect() as conn:
            mail = conn.execute(
                """SELECT m.*,
                EXISTS(SELECT 1 FROM viewer_favorites vf WHERE vf.mail_id=m.id) AS local_favorite
                FROM mails m WHERE m.id=? AND m.detail_status='complete'""",
                (mail_id,),
            ).fetchone()
            if mail is None:
                abort(404)
            images = conn.execute(
                "SELECT * FROM images WHERE mail_id=? ORDER BY position",
                (mail_id,),
            ).fetchall()
        body, remaining_images = _body_with_inline_images(
            mail["body_html"] or html.escape(mail["body_text"] or "").replace("\n", "<br>"),
            images,
        )
        back_url = _safe_local_url(request.args.get("return_to", "")) or url_for("index")
        return render_template_string(
            DETAIL_TEMPLATE,
            style=BASE_STYLE,
            mail=mail,
            remaining_images=remaining_images,
            body=body,
            back_url=back_url,
            current_url=request.full_path.rstrip("?"),
            favorite_token=favorite_token,
        )

    @app.post("/mail/<mail_id>/favorite")
    def set_favorite(mail_id: str):
        token = request.form.get("token", "")
        if not secrets.compare_digest(token, favorite_token):
            abort(400)
        favorite_value = request.form.get("favorite", "")
        if favorite_value not in {"0", "1"}:
            abort(400)
        if not storage.set_viewer_favorite(mail_id, favorite_value == "1"):
            abort(404)
        target = _safe_local_url(request.form.get("next", "")) or url_for("index")
        return redirect(target, code=303)

    @app.get("/image/<int:image_id>")
    def saved_image(image_id: int):
        with storage.connect() as conn:
            image = conn.execute(
                "SELECT * FROM images WHERE id=? AND status='complete'", (image_id,)
            ).fetchone()
        if image is None or not image["local_path"]:
            abort(404)
        path = (storage.data_dir / str(image["local_path"])).resolve()
        if not path.is_relative_to(storage.data_dir.resolve()) or not path.is_file():
            abort(404)
        return send_file(path, mimetype=image["content_type"] or "application/octet-stream")

    return app


class ViewerServer:
    def __init__(self, storage: Storage):
        self.app = create_viewer_app(storage)
        self.server: BaseWSGIServer | None = None
        self.thread: threading.Thread | None = None

    @property
    def url(self) -> str | None:
        if self.server is None:
            return None
        return f"http://127.0.0.1:{self.server.server_port}/"

    def start(self, open_browser: bool = True) -> str:
        if self.server is None:
            self.server = make_server("127.0.0.1", 0, self.app, threaded=True)
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
        assert self.url is not None
        if open_browser:
            webbrowser.open(self.url)
        return self.url

    def stop(self) -> None:
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
        self.server = None
        self.thread = None


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _safe_local_url(value: str) -> str | None:
    if not value.startswith("/") or value.startswith("//") or "\r" in value or "\n" in value:
        return None
    return value


def _body_with_inline_images(body_html: str, images: list[sqlite3.Row]) -> tuple[Markup, list[sqlite3.Row]]:
    """Replace legacy image markers with local saved images in their original positions."""
    soup = BeautifulSoup(body_html, "html.parser")
    markers = list(soup.select("span.image-marker"))
    marker_ids = {id(marker) for marker in markers}
    legacy_pattern = re.compile(r"^[\[［]\s*画像\s*[0-9０-９]+\s*[\]］]$")
    for span in soup.find_all("span"):
        if id(span) not in marker_ids and legacy_pattern.fullmatch(span.get_text(strip=True)):
            markers.append(span)
            marker_ids.add(id(span))
    used_ids: set[int] = set()
    for index, marker in enumerate(markers):
        if index >= len(images):
            marker.string = "［画像情報なし］"
            continue
        image = images[index]
        if image["status"] != "complete" or not image["local_path"]:
            marker.string = "［画像を保存できませんでした］"
            continue
        image_id = int(image["id"])
        used_ids.add(image_id)
        image_url = url_for("saved_image", image_id=image_id)
        link = soup.new_tag("a", href=image_url)
        link["class"] = "mail-inline-image-link"
        link["target"] = "_blank"
        link["rel"] = "noopener"
        tag = soup.new_tag("img", src=image_url)
        tag["class"] = "mail-inline-image"
        tag["alt"] = f"保存画像 {index + 1}"
        tag["loading"] = "lazy"
        link.append(tag)
        marker.replace_with(link)
    remaining = [
        image
        for image in images
        if image["status"] == "complete" and image["local_path"] and int(image["id"]) not in used_ids
    ]
    return Markup(str(soup)), remaining
