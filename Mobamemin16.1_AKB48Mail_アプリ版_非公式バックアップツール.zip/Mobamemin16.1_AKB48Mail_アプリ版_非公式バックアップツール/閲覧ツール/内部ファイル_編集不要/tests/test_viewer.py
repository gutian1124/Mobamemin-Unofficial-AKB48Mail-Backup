from __future__ import annotations

import importlib.util
import re
import sys
import tempfile
import unittest
from pathlib import Path

INTERNAL = Path(__file__).resolve().parents[1]
CANDIDATE_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(INTERNAL))

from akbviewer.gui import ViewerApp
from akbviewer.storage import Storage
from akbviewer.viewer import ViewerServer, create_viewer_app


def mail(mail_id: str, member: str, when: str, image: bool = False) -> dict:
    return {
        "id": mail_id,
        "member": {"id": 1, "name": member},
        "group": {"id": 1, "name": "AKB48"},
        "subject": f"件名 {mail_id}",
        "content": "本文プレビュー",
        "receive_datetime": when,
        "detail_url": f"https://web.akb48mail-appli.com/mail/{mail_id}",
        "is_image": image,
        "is_star": False,
    }


def load_api_storage_class():
    path = (
        CANDIDATE_ROOT
        / "API取得・バックアップツール"
        / "内部ファイル_編集不要"
        / "akbmail"
        / "storage.py"
    )
    spec = importlib.util.spec_from_file_location("split_test_api_storage", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("API tool storage module could not be loaded")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Storage


class ViewerIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.data_dir = Path(self.temp.name) / "バックアップデータ"
        api_storage_class = load_api_storage_class()
        api_storage = api_storage_class(self.data_dir)
        items = [
            mail("favorite", "テスト花子", "2026-08-29 10:00:00", True),
            mail("other", "テスト太郎", "2026-08-29 09:00:00"),
        ]
        api_storage.upsert_mails(items)
        for item in items:
            mail_id = str(item["id"])
            raw = api_storage.save_raw_detail(mail_id, "<div>本文</div>")
            body_html = (
                '<p>本文<span class="image-marker">［画像 1］</span>末尾</p>'
                if mail_id == "favorite"
                else "<p>本文</p>"
            )
            api_storage.mark_detail_complete(mail_id, raw, "本文", body_html)
        image_url = "https://img.akb48mail-appli.com/artist/mail/akb/favorite.jpg"
        api_storage.upsert_images("favorite", [image_url])
        image = api_storage.images_for_mail("favorite")[0]
        image_path = api_storage.image_dir / "favorite" / "000.jpg"
        image_path.parent.mkdir(parents=True, exist_ok=True)
        image_path.write_bytes(b"fake-jpeg")
        api_storage.mark_image_complete(int(image["id"]), image_path, "image/jpeg")
        self.storage = Storage(self.data_dir)

    def tearDown(self):
        self.temp.cleanup()

    def test_api_tool_database_is_searchable_and_images_are_local(self):
        app = create_viewer_app(self.storage)
        client = app.test_client()
        response = client.get("/?q=本文&member=テスト花子&has_image=yes")
        self.assertEqual(response.status_code, 200)
        self.assertIn("件名 favorite", response.get_data(as_text=True))
        self.assertIn("default-src 'none'", response.headers["Content-Security-Policy"])
        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")
        detail = client.get("/mail/favorite")
        self.assertEqual(detail.status_code, 200)
        self.assertNotIn(b"https://img.akb48mail-appli.com", detail.data)
        self.assertIn(b'class="mail-inline-image"', detail.data)
        with self.storage.connect() as conn:
            image_id = int(conn.execute("SELECT id FROM images LIMIT 1").fetchone()[0])
        saved = client.get(f"/image/{image_id}")
        self.assertEqual(saved.status_code, 200)
        self.assertEqual(saved.data, b"fake-jpeg")
        saved.close()

    def test_favorites_filter_and_both_back_links(self):
        app = create_viewer_app(self.storage)
        client = app.test_client()
        detail = client.get("/mail/favorite?return_to=/?q=件名")
        text = detail.get_data(as_text=True)
        self.assertEqual(text.count("← 一覧へ戻る"), 2)
        self.assertEqual(text.count('href="/?q=件名"'), 2)
        token_match = re.search(r'name="token" value="([^"]+)"', text)
        self.assertIsNotNone(token_match)
        token = token_match.group(1)
        added = client.post(
            "/mail/favorite/favorite",
            data={"token": token, "favorite": "1", "next": "/?favorite=yes"},
        )
        self.assertEqual(added.status_code, 303)
        filtered = client.get("/?favorite=yes").get_data(as_text=True)
        self.assertIn("件名 favorite", filtered)
        self.assertNotIn("件名 other", filtered)

        api_storage_class = load_api_storage_class()
        api_storage_class(self.data_dir).upsert_mails(
            [mail("favorite", "テスト花子", "2026-08-29 10:00:00", True)]
        )
        self.assertTrue(self.storage.is_viewer_favorite("favorite"))

    def test_server_binds_to_loopback_and_stops(self):
        server = ViewerServer(self.storage)
        try:
            url = server.start(open_browser=False)
            self.assertRegex(url, r"^http://127\.0\.0\.1:[0-9]+/$")
        finally:
            server.stop()
        self.assertIsNone(server.url)


class ViewerConfigurationTests(unittest.TestCase):
    def test_selected_data_directory_is_saved_and_reloaded(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            selected = root / "selected"
            selected.mkdir()
            app = ViewerApp.__new__(ViewerApp)
            app.default_data_dir = root / "default"
            app.state_dir = root / "state"
            app.config_path = app.state_dir / "viewer_config.json"
            app._save_data_dir(selected.resolve())
            self.assertEqual(app._load_data_dir(), selected.resolve())

    def test_missing_saved_directory_falls_back_to_default(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            app = ViewerApp.__new__(ViewerApp)
            app.default_data_dir = (root / "default").resolve()
            app.state_dir = root / "state"
            app.config_path = app.state_dir / "viewer_config.json"
            app.state_dir.mkdir()
            app.config_path.write_text(
                '{"data_dir":"C:/definitely/missing/split-viewer-test"}',
                encoding="utf-8",
            )
            self.assertEqual(app._load_data_dir(), app.default_data_dir)


class SeparationTests(unittest.TestCase):
    def test_tools_do_not_import_each_others_runtime(self):
        api_gui = (
            CANDIDATE_ROOT
            / "API取得・バックアップツール"
            / "内部ファイル_編集不要"
            / "akbmail"
            / "gui.py"
        ).read_text(encoding="utf-8")
        viewer_sources = "\n".join(
            path.read_text(encoding="utf-8")
            for path in (INTERNAL / "akbviewer").glob("*.py")
        )
        self.assertNotIn("ViewerServer", api_gui)
        self.assertNotIn("akbviewer", api_gui)
        self.assertNotIn("mitmproxy", viewer_sources)
        self.assertNotIn("akbmail", viewer_sources)

    def test_both_launchers_default_to_the_same_shared_data_directory(self):
        api_app = (
            CANDIDATE_ROOT / "API取得・バックアップツール" / "app.py"
        ).read_text(encoding="utf-8")
        viewer_app = (CANDIDATE_ROOT / "閲覧ツール" / "app.py").read_text(
            encoding="utf-8"
        )
        expected = 'ROOT.parent / "バックアップデータ"'
        self.assertIn(expected, api_app)
        self.assertIn(expected, viewer_app)


if __name__ == "__main__":
    unittest.main(verbosity=2)
